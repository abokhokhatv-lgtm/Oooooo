import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, User, Tag, ArrowRight, Search } from 'lucide-react';

const BlogPage = ({ language }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const content = {
    ar: {
      title: 'المدونة الروحانية',
      subtitle: 'مقالات وفيديوهات مجانية لتطوير رحلتك الروحانية',
      searchPlaceholder: 'ابحث في المقالات...',
      categories: {
        all: 'جميع المقالات',
        meditation: 'التأمل',
        healing: 'الشفاء',
        energy: 'الطاقة',
        spirituality: 'الروحانيات'
      },
      readMore: 'اقرأ المزيد',
      noResults: 'لا توجد مقالات تطابق بحثك',
      articles: [
        {
          id: 1,
          title: 'كيفية تطهير الطاقة السلبية من منزلك',
          excerpt: 'تعلم الطرق الفعالة لتطهير منزلك من الطاقات السلبية وخلق بيئة إيجابية مليئة بالسلام والهدوء...',
          category: 'energy',
          author: 'عمر علي',
          date: '2024-01-15',
          readTime: '5 دقائق',
          image: '/api/placeholder/400/250'
        },
        {
          id: 2,
          title: 'تقنيات التأمل للمبتدئين',
          excerpt: 'دليل شامل للمبتدئين في عالم التأمل، تعلم الأساسيات وابدأ رحلتك نحو السلام الداخلي...',
          category: 'meditation',
          author: 'عمر علي',
          date: '2024-01-10',
          readTime: '8 دقائق',
          image: '/api/placeholder/400/250'
        },
        {
          id: 3,
          title: 'فهم الشاكرات السبع وكيفية توازنها',
          excerpt: 'اكتشف مراكز الطاقة السبعة في جسمك وتعلم كيفية توازنها لتحقيق الصحة الجسدية والروحانية...',
          category: 'healing',
          author: 'عمر علي',
          date: '2024-01-05',
          readTime: '10 دقائق',
          image: '/api/placeholder/400/250'
        },
        {
          id: 4,
          title: 'الريكي: فن الشفاء بالطاقة الكونية',
          excerpt: 'تعرف على تقنية الريكي القديمة وكيف يمكن استخدامها للشفاء الذاتي ومساعدة الآخرين...',
          category: 'healing',
          author: 'عمر علي',
          date: '2023-12-28',
          readTime: '7 دقائق',
          image: '/api/placeholder/400/250'
        },
        {
          id: 5,
          title: 'علامات اليقظة الروحانية',
          excerpt: 'اكتشف العلامات التي تدل على بداية رحلة اليقظة الروحانية وكيفية التعامل مع هذه التجربة...',
          category: 'spirituality',
          author: 'عمر علي',
          date: '2023-12-20',
          readTime: '6 دقائق',
          image: '/api/placeholder/400/250'
        },
        {
          id: 6,
          title: 'تأمل الحب والرحمة',
          excerpt: 'تعلم تقنية تأمل الحب والرحمة لتطوير التعاطف مع الذات والآخرين وخلق علاقات أكثر إيجابية...',
          category: 'meditation',
          author: 'عمر علي',
          date: '2023-12-15',
          readTime: '9 دقائق',
          image: '/api/placeholder/400/250'
        }
      ]
    },
    en: {
      title: 'Spiritual Blog',
      subtitle: 'Free articles and videos to develop your spiritual journey',
      searchPlaceholder: 'Search articles...',
      categories: {
        all: 'All Articles',
        meditation: 'Meditation',
        healing: 'Healing',
        energy: 'Energy',
        spirituality: 'Spirituality'
      },
      readMore: 'Read More',
      noResults: 'No articles match your search',
      articles: [
        {
          id: 1,
          title: 'How to Cleanse Negative Energy from Your Home',
          excerpt: 'Learn effective ways to cleanse your home from negative energies and create a positive environment filled with peace and tranquility...',
          category: 'energy',
          author: 'Omar Ali',
          date: '2024-01-15',
          readTime: '5 min read',
          image: '/api/placeholder/400/250'
        },
        {
          id: 2,
          title: 'Meditation Techniques for Beginners',
          excerpt: 'A comprehensive guide for beginners in the world of meditation, learn the basics and start your journey towards inner peace...',
          category: 'meditation',
          author: 'Omar Ali',
          date: '2024-01-10',
          readTime: '8 min read',
          image: '/api/placeholder/400/250'
        },
        {
          id: 3,
          title: 'Understanding the Seven Chakras and How to Balance Them',
          excerpt: 'Discover the seven energy centers in your body and learn how to balance them to achieve physical and spiritual health...',
          category: 'healing',
          author: 'Omar Ali',
          date: '2024-01-05',
          readTime: '10 min read',
          image: '/api/placeholder/400/250'
        },
        {
          id: 4,
          title: 'Reiki: The Art of Healing with Universal Energy',
          excerpt: 'Learn about the ancient Reiki technique and how it can be used for self-healing and helping others...',
          category: 'healing',
          author: 'Omar Ali',
          date: '2023-12-28',
          readTime: '7 min read',
          image: '/api/placeholder/400/250'
        },
        {
          id: 5,
          title: 'Signs of Spiritual Awakening',
          excerpt: 'Discover the signs that indicate the beginning of a spiritual awakening journey and how to deal with this experience...',
          category: 'spirituality',
          author: 'Omar Ali',
          date: '2023-12-20',
          readTime: '6 min read',
          image: '/api/placeholder/400/250'
        },
        {
          id: 6,
          title: 'Loving-Kindness Meditation',
          excerpt: 'Learn the loving-kindness meditation technique to develop compassion for yourself and others and create more positive relationships...',
          category: 'meditation',
          author: 'Omar Ali',
          date: '2023-12-15',
          readTime: '9 min read',
          image: '/api/placeholder/400/250'
        }
      ]
    }
  };

  const t = content[language];

  const filteredArticles = t.articles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryColor = (category) => {
    const colors = {
      meditation: 'bg-blue-100 text-blue-800',
      healing: 'bg-green-100 text-green-800',
      energy: 'bg-purple-100 text-purple-800',
      spirituality: 'bg-yellow-100 text-yellow-800'
    };
    return colors[category] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/10 to-secondary/10">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">{t.title}</h1>
          <p className="text-xl text-gray-600">{t.subtitle}</p>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="py-12 bg-white border-b">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-6 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder={t.searchPlaceholder}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {Object.entries(t.categories).map(([key, label]) => (
                <Button
                  key={key}
                  variant={selectedCategory === key ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(key)}
                  className={selectedCategory === key ? "bg-primary hover:bg-primary/90" : ""}
                >
                  {label}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Articles Grid */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredArticles.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-xl text-gray-600">{t.noResults}</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredArticles.map((article) => (
                <Card key={article.id} className="hover-lift overflow-hidden">
                  <div className="aspect-video bg-gray-200 relative">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                      <span className="text-gray-600 font-medium">صورة المقال</span>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getCategoryColor(article.category)}`}>
                        {t.categories[article.category]}
                      </span>
                      <span className="text-sm text-gray-500">{article.readTime}</span>
                    </div>
                    
                    <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
                      {article.title}
                    </h3>
                    
                    <p className="text-gray-600 mb-4 line-clamp-3">
                      {article.excerpt}
                    </p>
                    
                    <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                      <div className="flex items-center">
                        <User className="h-4 w-4 mr-1" />
                        {article.author}
                      </div>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {new Date(article.date).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')}
                      </div>
                    </div>
                    
                    <Button variant="outline" className="w-full group">
                      {t.readMore}
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            {language === 'ar' ? 'اشترك في النشرة البريدية' : 'Subscribe to Newsletter'}
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            {language === 'ar' 
              ? 'احصل على آخر المقالات والنصائح الروحانية مباشرة في بريدك الإلكتروني'
              : 'Get the latest articles and spiritual tips directly in your email'
            }
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder={language === 'ar' ? 'أدخل بريدك الإلكتروني' : 'Enter your email'}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
            />
            <Button className="bg-primary hover:bg-primary/90 px-6">
              {language === 'ar' ? 'اشتراك' : 'Subscribe'}
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default BlogPage;

