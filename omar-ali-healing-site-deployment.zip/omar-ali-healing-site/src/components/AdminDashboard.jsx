import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Users, 
  DollarSign, 
  Calendar, 
  BookOpen, 
  TrendingUp, 
  Mail,
  Eye,
  Settings,
  BarChart3,
  PieChart,
  Activity
} from 'lucide-react';

const AdminDashboard = ({ language }) => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  const content = {
    ar: {
      title: 'لوحة التحكم',
      tabs: {
        overview: 'نظرة عامة',
        users: 'المستخدمين',
        bookings: 'الحجوزات',
        courses: 'الكورسات',
        revenue: 'الإيرادات',
        marketing: 'التسويق'
      },
      stats: {
        totalUsers: 'إجمالي المستخدمين',
        newUsersThisMonth: 'مستخدمين جدد هذا الشهر',
        activeSubscribers: 'المشتركين النشطين',
        totalRevenue: 'إجمالي الإيرادات',
        monthlyRevenue: 'إيرادات الشهر',
        totalBookings: 'إجمالي الحجوزات',
        pendingBookings: 'حجوزات معلقة',
        confirmedBookings: 'حجوزات مؤكدة',
        totalCourses: 'إجمالي الكورسات',
        publishedCourses: 'كورسات منشورة',
        totalEnrollments: 'إجمالي التسجيلات',
        newsletterSubscribers: 'مشتركي النشرة'
      },
      charts: {
        revenueOverTime: 'الإيرادات عبر الوقت',
        userGrowth: 'نمو المستخدمين',
        bookingsByStatus: 'الحجوزات حسب الحالة',
        topCourses: 'أفضل الكورسات'
      },
      recentActivities: {
        title: 'الأنشطة الحديثة',
        newUsers: 'مستخدمين جدد',
        recentBookings: 'حجوزات حديثة',
        recentPayments: 'مدفوعات حديثة'
      }
    },
    en: {
      title: 'Admin Dashboard',
      tabs: {
        overview: 'Overview',
        users: 'Users',
        bookings: 'Bookings',
        courses: 'Courses',
        revenue: 'Revenue',
        marketing: 'Marketing'
      },
      stats: {
        totalUsers: 'Total Users',
        newUsersThisMonth: 'New Users This Month',
        activeSubscribers: 'Active Subscribers',
        totalRevenue: 'Total Revenue',
        monthlyRevenue: 'Monthly Revenue',
        totalBookings: 'Total Bookings',
        pendingBookings: 'Pending Bookings',
        confirmedBookings: 'Confirmed Bookings',
        totalCourses: 'Total Courses',
        publishedCourses: 'Published Courses',
        totalEnrollments: 'Total Enrollments',
        newsletterSubscribers: 'Newsletter Subscribers'
      },
      charts: {
        revenueOverTime: 'Revenue Over Time',
        userGrowth: 'User Growth',
        bookingsByStatus: 'Bookings by Status',
        topCourses: 'Top Courses'
      },
      recentActivities: {
        title: 'Recent Activities',
        newUsers: 'New Users',
        recentBookings: 'Recent Bookings',
        recentPayments: 'Recent Payments'
      }
    }
  };

  const t = content[language];

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      const response = await fetch('/api/admin/dashboard/stats', {
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat(language === 'ar' ? 'ar-EG' : 'en-US', {
      style: 'currency',
      currency: 'EGP'
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="min-h-screen pt-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/4 mb-8"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const StatCard = ({ title, value, icon: Icon, color = 'primary', change }) => (
    <Card className="hover-lift">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-2xl font-bold text-gray-900">{value}</p>
            {change && (
              <p className={`text-sm ${change > 0 ? 'text-green-600' : 'text-red-600'}`}>
                {change > 0 ? '+' : ''}{change}%
              </p>
            )}
          </div>
          <div className={`p-3 rounded-full bg-${color}/10`}>
            <Icon className={`h-6 w-6 text-${color}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen pt-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">{t.title}</h1>
          <p className="text-gray-600 mt-2">
            {language === 'ar' 
              ? 'مرحباً بك في لوحة التحكم الخاصة بك'
              : 'Welcome to your admin dashboard'
            }
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-8">
          <nav className="flex space-x-8 rtl:space-x-reverse">
            {Object.entries(t.tabs).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === key
                    ? 'border-primary text-primary'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {label}
              </button>
            ))}
          </nav>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && stats && (
          <>
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <StatCard
                title={t.stats.totalUsers}
                value={stats.overview.total_users}
                icon={Users}
                color="blue"
              />
              <StatCard
                title={t.stats.activeSubscribers}
                value={stats.overview.active_subscribers}
                icon={Users}
                color="green"
              />
              <StatCard
                title={t.stats.totalRevenue}
                value={formatCurrency(stats.overview.total_revenue)}
                icon={DollarSign}
                color="yellow"
              />
              <StatCard
                title={t.stats.monthlyRevenue}
                value={formatCurrency(stats.overview.monthly_revenue)}
                icon={TrendingUp}
                color="green"
              />
              <StatCard
                title={t.stats.totalBookings}
                value={stats.overview.total_bookings}
                icon={Calendar}
                color="purple"
              />
              <StatCard
                title={t.stats.pendingBookings}
                value={stats.overview.pending_bookings}
                icon={Calendar}
                color="orange"
              />
              <StatCard
                title={t.stats.totalCourses}
                value={stats.overview.total_courses}
                icon={BookOpen}
                color="indigo"
              />
              <StatCard
                title={t.stats.newsletterSubscribers}
                value={stats.overview.newsletter_subscribers}
                icon={Mail}
                color="pink"
              />
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2" />
                    {t.charts.revenueOverTime}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    {language === 'ar' ? 'مخطط الإيرادات' : 'Revenue Chart'}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <PieChart className="h-5 w-5 mr-2" />
                    {t.charts.bookingsByStatus}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    {language === 'ar' ? 'مخطط الحجوزات' : 'Bookings Chart'}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Top Courses */}
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>{t.charts.topCourses}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stats.top_courses.map((course, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-medium">
                          {language === 'ar' ? course.title_ar : course.title_en}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {course.enrollment_count} {language === 'ar' ? 'تسجيل' : 'enrollments'}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-primary">
                          #{index + 1}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Activities */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="h-5 w-5 mr-2" />
                  {t.recentActivities.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Recent Users */}
                  <div>
                    <h4 className="font-medium mb-3">{t.recentActivities.newUsers}</h4>
                    <div className="space-y-2">
                      {stats.recent_activities.users.slice(0, 5).map((user) => (
                        <div key={user.id} className="flex items-center space-x-3 rtl:space-x-reverse">
                          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                            <Users className="h-4 w-4 text-primary" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">{user.username}</p>
                            <p className="text-xs text-gray-500">{user.email}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Recent Bookings */}
                  <div>
                    <h4 className="font-medium mb-3">{t.recentActivities.recentBookings}</h4>
                    <div className="space-y-2">
                      {stats.recent_activities.bookings.slice(0, 5).map((booking) => (
                        <div key={booking.id} className="flex items-center space-x-3 rtl:space-x-reverse">
                          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                            <Calendar className="h-4 w-4 text-green-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">{booking.user_name}</p>
                            <p className="text-xs text-gray-500">{booking.service_name}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Recent Payments */}
                  <div>
                    <h4 className="font-medium mb-3">{t.recentActivities.recentPayments}</h4>
                    <div className="space-y-2">
                      {stats.recent_activities.payments.slice(0, 5).map((payment) => (
                        <div key={payment.id} className="flex items-center space-x-3 rtl:space-x-reverse">
                          <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                            <DollarSign className="h-4 w-4 text-yellow-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">{payment.user_name}</p>
                            <p className="text-xs text-gray-500">
                              {formatCurrency(payment.amount)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}

        {/* Other tabs content would go here */}
        {activeTab !== 'overview' && (
          <Card>
            <CardContent className="p-8 text-center">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {language === 'ar' ? 'قريباً' : 'Coming Soon'}
              </h3>
              <p className="text-gray-600">
                {language === 'ar' 
                  ? 'هذا القسم قيد التطوير وسيكون متاحاً قريباً'
                  : 'This section is under development and will be available soon'
                }
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;

