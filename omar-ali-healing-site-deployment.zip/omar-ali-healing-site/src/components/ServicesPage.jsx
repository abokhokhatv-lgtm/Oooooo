import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Heart, Star, Users, Zap, Clock, CheckCircle, ArrowRight } from 'lucide-react';

const ServicesPage = ({ language }) => {
  const content = {
    ar: {
      title: 'خدماتي الروحانية',
      subtitle: 'اكتشف مجموعة شاملة من الخدمات الروحانية المصممة خصيصاً لتلبية احتياجاتك الفردية',
      services: {
        healing: {
          title: 'جلسات العلاج الروحاني',
          description: 'جلسات فردية مخصصة لتطهير الطاقة السلبية وتحقيق التوازن الداخلي من خلال تقنيات الريكي والعلاج بالطاقة',
          duration: '60-90 دقيقة',
          price: '200 جنيه',
          features: [
            'تقييم شامل للحالة الطاقية',
            'تطهير الشاكرات السبع',
            'علاج بالريكي والطاقة الكونية',
            'تقنيات التأمل العميق',
            'خطة شفاء مخصصة',
            'متابعة لمدة أسبوع'
          ]
        },
        consultation: {
          title: 'الاستشارات الروحانية',
          description: 'جلسات إرشاد روحاني لمساعدتك في اتخاذ القرارات المهمة وفهم رسالتك في الحياة',
          duration: '45 دقيقة',
          price: '150 جنيه',
          features: [
            'قراءة الطاقة الشخصية',
            'توجيه روحاني مخصص',
            'تحليل الأحلام والرؤى',
            'إرشاد في اتخاذ القرارات',
            'تقنيات الحماية الروحانية',
            'خطة تطوير روحاني'
          ]
        },
        workshops: {
          title: 'الورش التدريبية',
          description: 'ورش جماعية لتعلم تقنيات الشفاء الذاتي والتأمل العميق مع مجموعة من الأشخاص المتشابهين في التفكير',
          duration: '3-4 ساعات',
          price: '300 جنيه',
          features: [
            'تعلم تقنيات التأمل',
            'ممارسة الريكي الجماعي',
            'تمارين تطهير الطاقة',
            'تقنيات الحماية الروحانية',
            'شهادة حضور',
            'مواد تدريبية مجانية'
          ]
        },
        distance: {
          title: 'العلاج عن بُعد',
          description: 'جلسات شفاء روحاني عبر الإنترنت للأشخاص الذين لا يستطيعون الحضور شخصياً',
          duration: '45-60 دقيقة',
          price: '180 جنيه',
          features: [
            'جلسة عبر Zoom أو WhatsApp',
            'إرسال الطاقة عن بُعد',
            'تقنيات التأمل الموجه',
            'تسجيل الجلسة (اختياري)',
            'متابعة عبر الرسائل',
            'مرونة في المواعيد'
          ]
        }
      },
      process: {
        title: 'كيف تعمل جلساتي؟',
        steps: [
          {
            title: 'الاستشارة الأولية',
            description: 'نبدأ بمحادثة لفهم احتياجاتك وأهدافك من الجلسة'
          },
          {
            title: 'التقييم الطاقي',
            description: 'أقوم بفحص حالتك الطاقية وتحديد المناطق التي تحتاج للعلاج'
          },
          {
            title: 'العلاج والشفاء',
            description: 'تطبيق تقنيات الشفاء المناسبة لحالتك الفردية'
          },
          {
            title: 'المتابعة والإرشاد',
            description: 'تقديم نصائح وتمارين للمحافظة على التوازن الطاقي'
          }
        ]
      },
      cta: {
        title: 'جاهز لبدء رحلة الشفاء؟',
        subtitle: 'احجز جلستك الأولى اليوم واكتشف قوة الشفاء الداخلي',
        button: 'احجز جلسة الآن'
      }
    },
    en: {
      title: 'My Spiritual Services',
      subtitle: 'Discover a comprehensive range of spiritual services designed specifically to meet your individual needs',
      services: {
        healing: {
          title: 'Spiritual Healing Sessions',
          description: 'Individual sessions dedicated to cleansing negative energy and achieving inner balance through Reiki and energy healing techniques',
          duration: '60-90 minutes',
          price: '$25',
          features: [
            'Comprehensive energy assessment',
            'Seven chakras cleansing',
            'Reiki and cosmic energy healing',
            'Deep meditation techniques',
            'Personalized healing plan',
            'One week follow-up'
          ]
        },
        consultation: {
          title: 'Spiritual Consultations',
          description: 'Spiritual guidance sessions to help you make important decisions and understand your life purpose',
          duration: '45 minutes',
          price: '$20',
          features: [
            'Personal energy reading',
            'Customized spiritual guidance',
            'Dreams and visions analysis',
            'Decision-making guidance',
            'Spiritual protection techniques',
            'Spiritual development plan'
          ]
        },
        workshops: {
          title: 'Training Workshops',
          description: 'Group workshops to learn self-healing techniques and deep meditation with like-minded individuals',
          duration: '3-4 hours',
          price: '$40',
          features: [
            'Learn meditation techniques',
            'Group Reiki practice',
            'Energy cleansing exercises',
            'Spiritual protection techniques',
            'Certificate of attendance',
            'Free training materials'
          ]
        },
        distance: {
          title: 'Distance Healing',
          description: 'Online spiritual healing sessions for people who cannot attend in person',
          duration: '45-60 minutes',
          price: '$22',
          features: [
            'Session via Zoom or WhatsApp',
            'Remote energy transmission',
            'Guided meditation techniques',
            'Session recording (optional)',
            'Message follow-up',
            'Flexible scheduling'
          ]
        }
      },
      process: {
        title: 'How Do My Sessions Work?',
        steps: [
          {
            title: 'Initial Consultation',
            description: 'We start with a conversation to understand your needs and goals for the session'
          },
          {
            title: 'Energy Assessment',
            description: 'I examine your energy state and identify areas that need healing'
          },
          {
            title: 'Treatment and Healing',
            description: 'Apply appropriate healing techniques for your individual condition'
          },
          {
            title: 'Follow-up and Guidance',
            description: 'Provide advice and exercises to maintain energy balance'
          }
        ]
      },
      cta: {
        title: 'Ready to Start Your Healing Journey?',
        subtitle: 'Book your first session today and discover the power of inner healing',
        button: 'Book Session Now'
      }
    }
  };

  const t = content[language];

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/10 to-secondary/10">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">{t.title}</h1>
          <p className="text-xl text-gray-600">{t.subtitle}</p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Healing Sessions */}
            <Card className="hover-lift">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <Heart className="h-12 w-12 text-primary mr-4" />
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{t.services.healing.title}</h3>
                    <div className="flex items-center space-x-4 rtl:space-x-reverse mt-2">
                      <span className="flex items-center text-gray-600">
                        <Clock className="h-4 w-4 mr-1" />
                        {t.services.healing.duration}
                      </span>
                      <span className="text-2xl font-bold text-primary">{t.services.healing.price}</span>
                    </div>
                  </div>
                </div>
                <p className="text-gray-700 mb-6">{t.services.healing.description}</p>
                <ul className="space-y-3 mb-6">
                  {t.services.healing.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/booking">
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    احجز الآن
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Consultations */}
            <Card className="hover-lift">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <Star className="h-12 w-12 text-primary mr-4" />
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{t.services.consultation.title}</h3>
                    <div className="flex items-center space-x-4 rtl:space-x-reverse mt-2">
                      <span className="flex items-center text-gray-600">
                        <Clock className="h-4 w-4 mr-1" />
                        {t.services.consultation.duration}
                      </span>
                      <span className="text-2xl font-bold text-primary">{t.services.consultation.price}</span>
                    </div>
                  </div>
                </div>
                <p className="text-gray-700 mb-6">{t.services.consultation.description}</p>
                <ul className="space-y-3 mb-6">
                  {t.services.consultation.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/booking">
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    احجز الآن
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Workshops */}
            <Card className="hover-lift">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <Users className="h-12 w-12 text-primary mr-4" />
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{t.services.workshops.title}</h3>
                    <div className="flex items-center space-x-4 rtl:space-x-reverse mt-2">
                      <span className="flex items-center text-gray-600">
                        <Clock className="h-4 w-4 mr-1" />
                        {t.services.workshops.duration}
                      </span>
                      <span className="text-2xl font-bold text-primary">{t.services.workshops.price}</span>
                    </div>
                  </div>
                </div>
                <p className="text-gray-700 mb-6">{t.services.workshops.description}</p>
                <ul className="space-y-3 mb-6">
                  {t.services.workshops.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/booking">
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    احجز الآن
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Distance Healing */}
            <Card className="hover-lift">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <Zap className="h-12 w-12 text-primary mr-4" />
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{t.services.distance.title}</h3>
                    <div className="flex items-center space-x-4 rtl:space-x-reverse mt-2">
                      <span className="flex items-center text-gray-600">
                        <Clock className="h-4 w-4 mr-1" />
                        {t.services.distance.duration}
                      </span>
                      <span className="text-2xl font-bold text-primary">{t.services.distance.price}</span>
                    </div>
                  </div>
                </div>
                <p className="text-gray-700 mb-6">{t.services.distance.description}</p>
                <ul className="space-y-3 mb-6">
                  {t.services.distance.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-primary mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/booking">
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    احجز الآن
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-gray-900 text-center mb-16">{t.process.title}</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {t.process.steps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
                  {index + 1}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 spiritual-gradient">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white mb-4">{t.cta.title}</h2>
          <p className="text-xl text-white/90 mb-8">{t.cta.subtitle}</p>
          <Link to="/booking">
            <Button size="lg" className="bg-white text-primary hover:bg-gray-100 px-8 py-3">
              {t.cta.button}
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;

