import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Play, 
  Calendar, 
  BookOpen, 
  Mail, 
  Star, 
  Users, 
  Clock,
  Gift,
  CheckCircle,
  Heart
} from 'lucide-react';

const TikTokLandingPage = ({ language = 'ar' }) => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [loading, setLoading] = useState(false);

  const content = {
    ar: {
      hero: {
        title: 'مرحباً بك من TikTok! 🌟',
        subtitle: 'اكتشف قوة الشفاء الروحاني مع عمر علي',
        description: 'انضم لآلاف الأشخاص الذين غيروا حياتهم للأفضل'
      },
      stats: {
        clients: 'عميل سعيد',
        sessions: 'جلسة شفاء',
        courses: 'كورس تدريبي',
        rating: 'تقييم العملاء'
      },
      freeCourse: {
        title: 'كورس مجاني خاص لمتابعي TikTok',
        subtitle: 'مقدمة في الشفاء الروحاني',
        duration: '4 دروس مجانية',
        description: 'تعلم أساسيات الطاقة الروحانية والتأمل',
        features: [
          'تقنيات التأمل الأساسية',
          'تطهير الطاقة السلبية',
          'تحقيق التوازن الداخلي',
          'شهادة إتمام مجانية'
        ],
        cta: 'احصل على الكورس المجاني'
      },
      session: {
        title: 'احجز جلسة شفاء شخصية',
        subtitle: 'جلسة فردية مع المعالج عمر علي',
        price: '25 دولار',
        duration: '60 دقيقة',
        features: [
          'تقييم شامل للطاقة',
          'تطهير الشاكرات السبع',
          'علاج بالريكي والطاقة الكونية',
          'خطة شفاء شخصية',
          'متابعة لمدة أسبوع'
        ],
        cta: 'احجز جلستك الآن'
      },
      newsletter: {
        title: 'انضم لنشرتنا البريدية',
        subtitle: 'احصل على نصائح روحانية أسبوعية',
        placeholder: 'أدخل بريدك الإلكتروني',
        cta: 'اشترك الآن',
        success: 'تم الاشتراك بنجاح! ستصلك رسالة ترحيب قريباً'
      },
      testimonials: {
        title: 'ماذا يقول عملاؤنا',
        reviews: [
          {
            name: 'سارة أحمد',
            text: 'تجربة مذهلة! شعرت بتحسن كبير في طاقتي بعد الجلسة الأولى',
            rating: 5
          },
          {
            name: 'محمد علي',
            text: 'الكورسات ساعدتني كثيراً في فهم نفسي وتطوير قدراتي',
            rating: 5
          },
          {
            name: 'فاطمة حسن',
            text: 'أنصح الجميع بتجربة جلسات الشفاء مع الأستاذ عمر',
            rating: 5
          }
        ]
      },
      urgency: {
        title: 'عرض محدود لمتابعي TikTok',
        subtitle: 'خصم 20% على جميع الخدمات',
        code: 'TIKTOK20',
        expires: 'ينتهي خلال 48 ساعة'
      }
    },
    en: {
      hero: {
        title: 'Welcome from TikTok! 🌟',
        subtitle: 'Discover the Power of Spiritual Healing with Omar Ali',
        description: 'Join thousands who have transformed their lives for the better'
      },
      stats: {
        clients: 'Happy Clients',
        sessions: 'Healing Sessions',
        courses: 'Training Courses',
        rating: 'Client Rating'
      },
      freeCourse: {
        title: 'Free Course for TikTok Followers',
        subtitle: 'Introduction to Spiritual Healing',
        duration: '4 Free Lessons',
        description: 'Learn the basics of spiritual energy and meditation',
        features: [
          'Basic meditation techniques',
          'Negative energy cleansing',
          'Achieving inner balance',
          'Free completion certificate'
        ],
        cta: 'Get Free Course'
      },
      session: {
        title: 'Book Personal Healing Session',
        subtitle: 'One-on-one session with healer Omar Ali',
        price: '$25',
        duration: '60 minutes',
        features: [
          'Comprehensive energy assessment',
          'Seven chakras cleansing',
          'Reiki and cosmic energy healing',
          'Personal healing plan',
          'One week follow-up'
        ],
        cta: 'Book Your Session Now'
      },
      newsletter: {
        title: 'Join Our Newsletter',
        subtitle: 'Get weekly spiritual tips',
        placeholder: 'Enter your email',
        cta: 'Subscribe Now',
        success: 'Successfully subscribed! You will receive a welcome message soon'
      },
      testimonials: {
        title: 'What Our Clients Say',
        reviews: [
          {
            name: 'Sarah Ahmed',
            text: 'Amazing experience! I felt a great improvement in my energy after the first session',
            rating: 5
          },
          {
            name: 'Mohamed Ali',
            text: 'The courses helped me a lot in understanding myself and developing my abilities',
            rating: 5
          },
          {
            name: 'Fatima Hassan',
            text: 'I recommend everyone to try healing sessions with Mr. Omar',
            rating: 5
          }
        ]
      },
      urgency: {
        title: 'Limited Offer for TikTok Followers',
        subtitle: '20% Discount on All Services',
        code: 'TIKTOK20',
        expires: 'Expires in 48 hours'
      }
    }
  };

  const t = content[language];

  const handleNewsletterSubscribe = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('/api/newsletter/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          source: 'tiktok_landing',
          language_preference: language
        }),
      });

      if (response.ok) {
        setIsSubscribed(true);
        setEmail('');
      }
    } catch (error) {
      console.error('Newsletter subscription failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const StatCard = ({ number, label, icon: Icon }) => (
    <div className="text-center">
      <div className="flex justify-center mb-2">
        <Icon className="h-8 w-8 text-primary" />
      </div>
      <div className="text-3xl font-bold text-primary mb-1">{number}</div>
      <div className="text-sm text-gray-600">{label}</div>
    </div>
  );

  const FeatureItem = ({ text }) => (
    <div className="flex items-center space-x-2 rtl:space-x-reverse">
      <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
      <span className="text-gray-700">{text}</span>
    </div>
  );

  const TestimonialCard = ({ review }) => (
    <Card className="h-full">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          {[...Array(review.rating)].map((_, i) => (
            <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
          ))}
        </div>
        <p className="text-gray-700 mb-4">"{review.text}"</p>
        <div className="font-medium text-primary">{review.name}</div>
      </CardContent>
    </Card>
  );

  return (
    <div className={`min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5 ${language === 'ar' ? 'font-arabic' : 'font-english'}`} dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Hero Section */}
      <section className="pt-20 pb-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            {t.hero.title}
          </h1>
          <h2 className="text-2xl md:text-3xl text-primary mb-4">
            {t.hero.subtitle}
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            {t.hero.description}
          </p>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <StatCard number="500+" label={t.stats.clients} icon={Users} />
            <StatCard number="1000+" label={t.stats.sessions} icon={Heart} />
            <StatCard number="25+" label={t.stats.courses} icon={BookOpen} />
            <StatCard number="4.9" label={t.stats.rating} icon={Star} />
          </div>
        </div>
      </section>

      {/* Urgency Banner */}
      <section className="bg-gradient-to-r from-red-500 to-pink-500 text-white py-4">
        <div className="max-w-4xl mx-auto text-center px-4">
          <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse">
            <Gift className="h-6 w-6" />
            <span className="font-bold">{t.urgency.title}</span>
          </div>
          <div className="text-sm mt-1">
            {t.urgency.subtitle} - كود: <span className="font-bold">{t.urgency.code}</span>
          </div>
          <div className="text-xs mt-1 opacity-90">{t.urgency.expires}</div>
        </div>
      </section>

      {/* Free Course Section */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-2 border-primary/20">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className="bg-primary/10 p-4 rounded-full">
                  <BookOpen className="h-12 w-12 text-primary" />
                </div>
              </div>
              <CardTitle className="text-3xl text-primary mb-2">
                {t.freeCourse.title}
              </CardTitle>
              <p className="text-xl text-gray-700">{t.freeCourse.subtitle}</p>
              <div className="flex items-center justify-center space-x-4 rtl:space-x-reverse mt-4">
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <Clock className="h-5 w-5 text-primary" />
                  <span className="text-primary font-medium">{t.freeCourse.duration}</span>
                </div>
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <Gift className="h-5 w-5 text-green-500" />
                  <span className="text-green-500 font-medium">مجاني 100%</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="px-8 pb-8">
              <p className="text-center text-gray-600 mb-6">{t.freeCourse.description}</p>
              
              <div className="grid md:grid-cols-2 gap-4 mb-8">
                {t.freeCourse.features.map((feature, index) => (
                  <FeatureItem key={index} text={feature} />
                ))}
              </div>

              <div className="text-center">
                <Button 
                  size="lg" 
                  className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 text-lg"
                  onClick={() => window.location.href = '/courses'}
                >
                  <BookOpen className="h-5 w-5 mr-2" />
                  {t.freeCourse.cta}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Session Booking Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <Card className="border-2 border-primary/20">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className="bg-primary/10 p-4 rounded-full">
                  <Calendar className="h-12 w-12 text-primary" />
                </div>
              </div>
              <CardTitle className="text-3xl text-primary mb-2">
                {t.session.title}
              </CardTitle>
              <p className="text-xl text-gray-700">{t.session.subtitle}</p>
              <div className="flex items-center justify-center space-x-4 rtl:space-x-reverse mt-4">
                <div className="text-3xl font-bold text-primary">{t.session.price}</div>
                <div className="text-gray-600">{t.session.duration}</div>
              </div>
            </CardHeader>
            <CardContent className="px-8 pb-8">
              <div className="grid md:grid-cols-2 gap-4 mb-8">
                {t.session.features.map((feature, index) => (
                  <FeatureItem key={index} text={feature} />
                ))}
              </div>

              <div className="text-center">
                <Button 
                  size="lg" 
                  className="bg-primary hover:bg-primary/90 text-white px-8 py-4 text-lg"
                  onClick={() => window.location.href = '/booking'}
                >
                  <Calendar className="h-5 w-5 mr-2" />
                  {t.session.cta}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-primary/10 to-secondary/10">
        <div className="max-w-2xl mx-auto text-center">
          <div className="flex justify-center mb-6">
            <div className="bg-primary/10 p-4 rounded-full">
              <Mail className="h-12 w-12 text-primary" />
            </div>
          </div>
          <h3 className="text-3xl font-bold text-gray-900 mb-4">
            {t.newsletter.title}
          </h3>
          <p className="text-xl text-gray-600 mb-8">
            {t.newsletter.subtitle}
          </p>

          {isSubscribed ? (
            <div className="bg-green-100 border border-green-400 text-green-700 px-6 py-4 rounded-lg">
              <CheckCircle className="h-6 w-6 mx-auto mb-2" />
              {t.newsletter.success}
            </div>
          ) : (
            <form onSubmit={handleNewsletterSubscribe} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t.newsletter.placeholder}
                required
                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <Button 
                type="submit" 
                disabled={loading}
                className="bg-primary hover:bg-primary/90 px-6 py-3"
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                ) : (
                  <>
                    <Mail className="h-5 w-5 mr-2" />
                    {t.newsletter.cta}
                  </>
                )}
              </Button>
            </form>
          )}
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
            {t.testimonials.title}
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            {t.testimonials.reviews.map((review, index) => (
              <TestimonialCard key={index} review={review} />
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 px-4 bg-gradient-to-r from-primary to-secondary text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-3xl md:text-4xl font-bold mb-6">
            {language === 'ar' ? 'ابدأ رحلتك الروحانية اليوم' : 'Start Your Spiritual Journey Today'}
          </h3>
          <p className="text-xl mb-8 opacity-90">
            {language === 'ar' 
              ? 'انضم لآلاف الأشخاص الذين غيروا حياتهم للأفضل'
              : 'Join thousands who have transformed their lives for the better'
            }
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-primary hover:bg-gray-100 px-8 py-4 text-lg"
              onClick={() => window.location.href = '/courses'}
            >
              <BookOpen className="h-5 w-5 mr-2" />
              {language === 'ar' ? 'الكورس المجاني' : 'Free Course'}
            </Button>
            <Button 
              size="lg" 
              className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-primary px-8 py-4 text-lg"
              onClick={() => window.location.href = '/booking'}
            >
              <Calendar className="h-5 w-5 mr-2" />
              {language === 'ar' ? 'احجز جلسة' : 'Book Session'}
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default TikTokLandingPage;

