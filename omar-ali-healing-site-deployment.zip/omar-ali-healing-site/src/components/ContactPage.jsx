import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Phone, Mail, MapPin, Clock, Facebook, Instagram, MessageCircle, Send } from 'lucide-react';

const ContactPage = ({ language }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const content = {
    ar: {
      title: 'تواصل معي',
      subtitle: 'أنا هنا لمساعدتك في رحلتك الروحانية. لا تتردد في التواصل معي',
      form: {
        title: 'أرسل رسالة',
        name: 'الاسم الكامل',
        email: 'البريد الإلكتروني',
        phone: 'رقم الهاتف',
        subject: 'الموضوع',
        message: 'الرسالة',
        send: 'إرسال الرسالة',
        namePlaceholder: 'أدخل اسمك الكامل',
        emailPlaceholder: 'أدخل بريدك الإلكتروني',
        phonePlaceholder: 'أدخل رقم هاتفك',
        subjectPlaceholder: 'موضوع الرسالة',
        messagePlaceholder: 'اكتب رسالتك هنا...'
      },
      contact: {
        title: 'معلومات التواصل',
        phone: '+20 123 456 7890',
        email: 'info@omarali.com',
        address: 'القاهرة، مصر',
        hours: 'الأحد - الخميس: 9:00 ص - 6:00 م'
      },
      social: {
        title: 'تابعني على وسائل التواصل',
        whatsapp: 'واتساب',
        facebook: 'فيسبوك',
        instagram: 'إنستجرام',
        email: 'إيميل'
      },
      faq: {
        title: 'الأسئلة الشائعة',
        questions: [
          {
            question: 'كم تستغرق الجلسة الواحدة؟',
            answer: 'تتراوح مدة الجلسة بين 60-90 دقيقة حسب نوع العلاج المطلوب.'
          },
          {
            question: 'هل يمكن إجراء جلسات عن بُعد؟',
            answer: 'نعم، أقدم جلسات شفاء عن بُعد عبر Zoom أو WhatsApp بنفس الفعالية.'
          },
          {
            question: 'كم عدد الجلسات المطلوبة؟',
            answer: 'يختلف العدد حسب الحالة، لكن معظم العملاء يشعرون بتحسن من الجلسة الأولى.'
          },
          {
            question: 'هل العلاج الروحاني آمن؟',
            answer: 'نعم، العلاج الروحاني آمن تماماً ولا يوجد له أي آثار جانبية سلبية.'
          }
        ]
      }
    },
    en: {
      title: 'Contact Me',
      subtitle: 'I am here to help you on your spiritual journey. Feel free to reach out to me',
      form: {
        title: 'Send a Message',
        name: 'Full Name',
        email: 'Email Address',
        phone: 'Phone Number',
        subject: 'Subject',
        message: 'Message',
        send: 'Send Message',
        namePlaceholder: 'Enter your full name',
        emailPlaceholder: 'Enter your email address',
        phonePlaceholder: 'Enter your phone number',
        subjectPlaceholder: 'Message subject',
        messagePlaceholder: 'Write your message here...'
      },
      contact: {
        title: 'Contact Information',
        phone: '+20 123 456 7890',
        email: 'info@omarali.com',
        address: 'Cairo, Egypt',
        hours: 'Sunday - Thursday: 9:00 AM - 6:00 PM'
      },
      social: {
        title: 'Follow Me on Social Media',
        whatsapp: 'WhatsApp',
        facebook: 'Facebook',
        instagram: 'Instagram',
        email: 'Email'
      },
      faq: {
        title: 'Frequently Asked Questions',
        questions: [
          {
            question: 'How long does each session take?',
            answer: 'Sessions range from 60-90 minutes depending on the type of treatment required.'
          },
          {
            question: 'Can sessions be conducted remotely?',
            answer: 'Yes, I offer remote healing sessions via Zoom or WhatsApp with the same effectiveness.'
          },
          {
            question: 'How many sessions are required?',
            answer: 'The number varies depending on the condition, but most clients feel improvement from the first session.'
          },
          {
            question: 'Is spiritual healing safe?',
            answer: 'Yes, spiritual healing is completely safe and has no negative side effects.'
          }
        ]
      }
    }
  };

  const t = content[language];

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Form submitted:', formData);
    alert(language === 'ar' ? 'تم إرسال رسالتك بنجاح!' : 'Your message has been sent successfully!');
  };

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/10 to-secondary/10">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">{t.title}</h1>
          <p className="text-xl text-gray-600">{t.subtitle}</p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="hover-lift">
              <CardContent className="p-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-6">{t.form.title}</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t.form.name}
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder={t.form.namePlaceholder}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t.form.email}
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder={t.form.emailPlaceholder}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t.form.phone}
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder={t.form.phonePlaceholder}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t.form.subject}
                    </label>
                    <input
                      type="text"
                      name="subject"
                      value={formData.subject}
                      onChange={handleInputChange}
                      placeholder={t.form.subjectPlaceholder}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t.form.message}
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder={t.form.messagePlaceholder}
                      rows={6}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90 py-3">
                    <Send className="mr-2 h-5 w-5" />
                    {t.form.send}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <div className="space-y-8">
              {/* Contact Details */}
              <Card className="hover-lift">
                <CardContent className="p-8">
                  <h2 className="text-3xl font-bold text-gray-900 mb-6">{t.contact.title}</h2>
                  <div className="space-y-6">
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <Phone className="h-6 w-6 text-primary" />
                      <div>
                        <p className="font-medium text-gray-900">{language === 'ar' ? 'الهاتف' : 'Phone'}</p>
                        <p className="text-gray-600">{t.contact.phone}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <Mail className="h-6 w-6 text-primary" />
                      <div>
                        <p className="font-medium text-gray-900">{language === 'ar' ? 'البريد الإلكتروني' : 'Email'}</p>
                        <p className="text-gray-600">{t.contact.email}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <MapPin className="h-6 w-6 text-primary" />
                      <div>
                        <p className="font-medium text-gray-900">{language === 'ar' ? 'العنوان' : 'Address'}</p>
                        <p className="text-gray-600">{t.contact.address}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <Clock className="h-6 w-6 text-primary" />
                      <div>
                        <p className="font-medium text-gray-900">{language === 'ar' ? 'ساعات العمل' : 'Working Hours'}</p>
                        <p className="text-gray-600">{t.contact.hours}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Social Media */}
              <Card className="hover-lift">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-6">{t.social.title}</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <a
                      href="https://wa.me/201234567890"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center space-x-3 rtl:space-x-reverse p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors"
                    >
                      <MessageCircle className="h-6 w-6 text-green-600" />
                      <span className="font-medium text-green-700">{t.social.whatsapp}</span>
                    </a>

                    <a
                      href="https://facebook.com/omarali"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center space-x-3 rtl:space-x-reverse p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                    >
                      <Facebook className="h-6 w-6 text-blue-600" />
                      <span className="font-medium text-blue-700">{t.social.facebook}</span>
                    </a>

                    <a
                      href="https://instagram.com/omarali"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center space-x-3 rtl:space-x-reverse p-4 bg-pink-50 hover:bg-pink-100 rounded-lg transition-colors"
                    >
                      <Instagram className="h-6 w-6 text-pink-600" />
                      <span className="font-medium text-pink-700">{t.social.instagram}</span>
                    </a>

                    <a
                      href="mailto:info@omarali.com"
                      className="flex items-center justify-center space-x-3 rtl:space-x-reverse p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <Mail className="h-6 w-6 text-gray-600" />
                      <span className="font-medium text-gray-700">{t.social.email}</span>
                    </a>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">{t.faq.title}</h2>
          <div className="space-y-6">
            {t.faq.questions.map((faq, index) => (
              <Card key={index} className="hover-lift">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">{faq.question}</h3>
                  <p className="text-gray-700">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;

