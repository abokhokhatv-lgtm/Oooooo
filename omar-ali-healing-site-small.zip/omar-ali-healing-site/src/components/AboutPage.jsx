import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Award, Heart, Star, Users } from 'lucide-react';

const AboutPage = ({ language }) => {
  const content = {
    ar: {
      title: 'من أنا',
      subtitle: 'تعرف على رحلتي في عالم الشفاء الروحاني',
      intro: {
        title: 'عمر علي - المعالج الروحاني',
        text: 'أهلاً وسهلاً بك في عالمي الروحاني. أنا عمر علي، معالج روحاني متخصص في تقنيات الشفاء بالطاقة والتأمل العميق. بدأت رحلتي في هذا المجال منذ أكثر من 10 سنوات، وخلال هذه الفترة ساعدت المئات من الأشخاص في تحقيق التوازن الداخلي والشفاء الروحاني.'
      },
      philosophy: {
        title: 'فلسفتي في الشفاء',
        text: 'أؤمن بأن كل إنسان يحمل في داخله قوة شفاء عظيمة، وأن دوري كمعالج روحاني هو مساعدتك في اكتشاف هذه القوة وتفعيلها. أستخدم مزيجاً من التقنيات التقليدية والحديثة في العلاج، مع التركيز على الجانب الروحاني والنفسي للإنسان.'
      },
      journey: {
        title: 'رحلتي الروحانية',
        text: 'بدأت اهتمامي بالعلوم الروحانية في سن مبكرة، حيث كنت أشعر بوجود طاقة خاصة في داخلي. سافرت إلى العديد من البلدان لدراسة تقنيات الشفاء المختلفة، وتدربت على يد أساتذة مختصين في الهند والتبت ومصر. حصلت على شهادات معتمدة في الريكي، والعلاج بالكريستال، والتأمل العميق.'
      },
      values: {
        title: 'قيمي ومبادئي',
        compassion: {
          title: 'الرحمة والتعاطف',
          description: 'أتعامل مع كل عميل بحب ورحمة، وأؤمن بأن الشفاء يبدأ من القلب'
        },
        authenticity: {
          title: 'الأصالة والصدق',
          description: 'أقدم خدماتي بصدق وشفافية، وأؤمن بأهمية الثقة بين المعالج والعميل'
        },
        growth: {
          title: 'النمو المستمر',
          description: 'أسعى دائماً لتطوير مهاراتي وتعلم تقنيات جديدة لخدمة عملائي بشكل أفضل'
        },
        holistic: {
          title: 'الشفاء الشامل',
          description: 'أؤمن بالشفاء الشامل للجسد والعقل والروح كوحدة واحدة متكاملة'
        }
      },
      achievements: {
        title: 'إنجازاتي وشهاداتي',
        items: [
          'شهادة معتمدة في الريكي من المعهد الدولي للطاقة',
          'دبلوم في العلاج بالكريستال من أكاديمية الشفاء الطبيعي',
          'شهادة في التأمل العميق من مركز التبت للتأمل',
          'عضو في الجمعية الدولية للمعالجين الروحانيين',
          'مؤلف كتاب "رحلة الشفاء الداخلي"',
          'محاضر في العديد من المؤتمرات الروحانية'
        ]
      }
    },
    en: {
      title: 'About Me',
      subtitle: 'Learn about my journey in the world of spiritual healing',
      intro: {
        title: 'Omar Ali - Spiritual Healer',
        text: 'Welcome to my spiritual world. I am Omar Ali, a spiritual healer specialized in energy healing techniques and deep meditation. I started my journey in this field more than 10 years ago, and during this period I have helped hundreds of people achieve inner balance and spiritual healing.'
      },
      philosophy: {
        title: 'My Healing Philosophy',
        text: 'I believe that every human being carries within them a great healing power, and that my role as a spiritual healer is to help you discover and activate this power. I use a combination of traditional and modern healing techniques, focusing on the spiritual and psychological aspects of the human being.'
      },
      journey: {
        title: 'My Spiritual Journey',
        text: 'My interest in spiritual sciences began at an early age, where I felt a special energy within me. I traveled to many countries to study different healing techniques, and trained under specialized masters in India, Tibet, and Egypt. I obtained certified certificates in Reiki, Crystal Healing, and Deep Meditation.'
      },
      values: {
        title: 'My Values and Principles',
        compassion: {
          title: 'Compassion and Empathy',
          description: 'I treat each client with love and compassion, believing that healing begins from the heart'
        },
        authenticity: {
          title: 'Authenticity and Honesty',
          description: 'I provide my services with honesty and transparency, believing in the importance of trust between healer and client'
        },
        growth: {
          title: 'Continuous Growth',
          description: 'I always strive to develop my skills and learn new techniques to serve my clients better'
        },
        holistic: {
          title: 'Holistic Healing',
          description: 'I believe in holistic healing of body, mind, and spirit as one integrated unit'
        }
      },
      achievements: {
        title: 'My Achievements and Certifications',
        items: [
          'Certified Reiki Master from International Energy Institute',
          'Diploma in Crystal Healing from Natural Healing Academy',
          'Certificate in Deep Meditation from Tibet Meditation Center',
          'Member of International Association of Spiritual Healers',
          'Author of "The Inner Healing Journey" book',
          'Speaker at numerous spiritual conferences'
        ]
      }
    }
  };

  const t = content[language];

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/10 to-secondary/10">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">{t.title}</h1>
          <p className="text-xl text-gray-600">{t.subtitle}</p>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="w-32 h-32 bg-primary rounded-full mx-auto mb-6 flex items-center justify-center">
              <span className="text-4xl font-bold text-white">عمر</span>
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">{t.intro.title}</h2>
            <p className="text-lg text-gray-700 leading-relaxed">{t.intro.text}</p>
          </div>
        </div>
      </section>

      {/* Philosophy */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">{t.philosophy.title}</h2>
          <p className="text-lg text-gray-700 leading-relaxed text-center">{t.philosophy.text}</p>
        </div>
      </section>

      {/* Journey */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">{t.journey.title}</h2>
          <p className="text-lg text-gray-700 leading-relaxed text-center">{t.journey.text}</p>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">{t.values.title}</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="hover-lift">
              <CardContent className="p-6 text-center">
                <Heart className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">{t.values.compassion.title}</h3>
                <p className="text-gray-600">{t.values.compassion.description}</p>
              </CardContent>
            </Card>
            
            <Card className="hover-lift">
              <CardContent className="p-6 text-center">
                <Star className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">{t.values.authenticity.title}</h3>
                <p className="text-gray-600">{t.values.authenticity.description}</p>
              </CardContent>
            </Card>
            
            <Card className="hover-lift">
              <CardContent className="p-6 text-center">
                <Users className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">{t.values.growth.title}</h3>
                <p className="text-gray-600">{t.values.growth.description}</p>
              </CardContent>
            </Card>
            
            <Card className="hover-lift">
              <CardContent className="p-6 text-center">
                <Award className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">{t.values.holistic.title}</h3>
                <p className="text-gray-600">{t.values.holistic.description}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">{t.achievements.title}</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {t.achievements.items.map((item, index) => (
              <div key={index} className="flex items-center space-x-3 rtl:space-x-reverse p-4 bg-white rounded-lg shadow-sm border">
                <Award className="h-6 w-6 text-primary flex-shrink-0" />
                <span className="text-gray-700">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;

