import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Heart, Star, Users, Award, ArrowRight, Play } from 'lucide-react';
import heroImage from '../assets/YJpEDXTP2OAp.jpg';
import spiritualImage from '../assets/JXq1N8Q3uCYG.jpg';

const HomePage = ({ language }) => {
  const content = {
    ar: {
      hero: {
        title: 'مرحباً بك في عالم الشفاء الروحاني',
        subtitle: 'اكتشف قوة الطاقة الداخلية وحقق التوازن في حياتك مع المعالج الروحاني عمر علي',
        cta1: 'احجز جلسة الآن',
        cta2: 'تعرف على خدماتي',
        watchVideo: 'شاهد الفيديو التعريفي'
      },
      stats: {
        clients: 'عميل سعيد',
        experience: 'سنوات خبرة',
        sessions: 'جلسة علاج',
        courses: 'كورس تدريبي'
      },
      services: {
        title: 'خدماتي الروحانية',
        subtitle: 'أقدم لك مجموعة شاملة من الخدمات الروحانية المصممة خصيصاً لتلبية احتياجاتك',
        healing: {
          title: 'جلسات العلاج الروحاني',
          description: 'جلسات فردية مخصصة لتطهير الطاقة السلبية وتحقيق التوازن الداخلي'
        },
        consultation: {
          title: 'الاستشارات الروحانية',
          description: 'إرشاد ونصائح روحانية لمساعدتك في اتخاذ القرارات المهمة في حياتك'
        },
        workshops: {
          title: 'الورش التدريبية',
          description: 'ورش جماعية لتعلم تقنيات الشفاء الذاتي والتأمل العميق'
        }
      },
      testimonials: {
        title: 'آراء العملاء',
        subtitle: 'اكتشف كيف غيرت جلساتي حياة الآخرين',
        testimonial1: {
          text: 'تجربة مذهلة مع الأستاذ عمر. شعرت بتحسن كبير في طاقتي وحالتي النفسية بعد الجلسة الأولى.',
          name: 'سارة أحمد',
          role: 'مهندسة'
        },
        testimonial2: {
          text: 'الكورسات التدريبية ساعدتني كثيراً في فهم نفسي وتطوير قدراتي الروحانية.',
          name: 'محمد علي',
          role: 'مدرس'
        }
      },
      cta: {
        title: 'ابدأ رحلتك الروحانية اليوم',
        subtitle: 'احجز جلستك الأولى واكتشف قوة الشفاء الداخلي',
        button: 'احجز الآن'
      }
    },
    en: {
      hero: {
        title: 'Welcome to the World of Spiritual Healing',
        subtitle: 'Discover the power of inner energy and achieve balance in your life with spiritual healer Omar Ali',
        cta1: 'Book Session Now',
        cta2: 'Explore My Services',
        watchVideo: 'Watch Introduction Video'
      },
      stats: {
        clients: 'Happy Clients',
        experience: 'Years Experience',
        sessions: 'Healing Sessions',
        courses: 'Training Courses'
      },
      services: {
        title: 'My Spiritual Services',
        subtitle: 'I offer you a comprehensive range of spiritual services designed specifically to meet your needs',
        healing: {
          title: 'Spiritual Healing Sessions',
          description: 'Individual sessions dedicated to cleansing negative energy and achieving inner balance'
        },
        consultation: {
          title: 'Spiritual Consultations',
          description: 'Spiritual guidance and advice to help you make important decisions in your life'
        },
        workshops: {
          title: 'Training Workshops',
          description: 'Group workshops to learn self-healing techniques and deep meditation'
        }
      },
      testimonials: {
        title: 'Client Reviews',
        subtitle: 'Discover how my sessions have changed the lives of others',
        testimonial1: {
          text: 'Amazing experience with Mr. Omar. I felt a great improvement in my energy and mental state after the first session.',
          name: 'Sarah Ahmed',
          role: 'Engineer'
        },
        testimonial2: {
          text: 'The training courses helped me a lot in understanding myself and developing my spiritual abilities.',
          name: 'Mohamed Ali',
          role: 'Teacher'
        }
      },
      cta: {
        title: 'Start Your Spiritual Journey Today',
        subtitle: 'Book your first session and discover the power of inner healing',
        button: 'Book Now'
      }
    }
  };

  const t = content[language];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in-up">
            {t.hero.title}
          </h1>
          <p className="text-xl md:text-2xl mb-8 opacity-90 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            {t.hero.subtitle}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
            <Link to="/booking">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-white px-8 py-3">
                {t.hero.cta1}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/services">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-black px-8 py-3">
                {t.hero.cta2}
              </Button>
            </Link>
          </div>
          <div className="mt-8 animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
            <Button variant="ghost" className="text-white hover:bg-white/20">
              <Play className="mr-2 h-5 w-5" />
              {t.hero.watchVideo}
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">500+</div>
              <div className="text-gray-600">{t.stats.clients}</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">10+</div>
              <div className="text-gray-600">{t.stats.experience}</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">1000+</div>
              <div className="text-gray-600">{t.stats.sessions}</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">25+</div>
              <div className="text-gray-600">{t.stats.courses}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">{t.services.title}</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">{t.services.subtitle}</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="hover-lift">
              <CardContent className="p-8 text-center">
                <Heart className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-2xl font-semibold mb-4">{t.services.healing.title}</h3>
                <p className="text-gray-600">{t.services.healing.description}</p>
              </CardContent>
            </Card>
            
            <Card className="hover-lift">
              <CardContent className="p-8 text-center">
                <Star className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-2xl font-semibold mb-4">{t.services.consultation.title}</h3>
                <p className="text-gray-600">{t.services.consultation.description}</p>
              </CardContent>
            </Card>
            
            <Card className="hover-lift">
              <CardContent className="p-8 text-center">
                <Users className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-2xl font-semibold mb-4">{t.services.workshops.title}</h3>
                <p className="text-gray-600">{t.services.workshops.description}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">{t.testimonials.title}</h2>
            <p className="text-xl text-gray-600">{t.testimonials.subtitle}</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="hover-lift">
              <CardContent className="p-8">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 text-lg">"{t.testimonials.testimonial1.text}"</p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-semibold mr-4">
                    {t.testimonials.testimonial1.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-semibold">{t.testimonials.testimonial1.name}</div>
                    <div className="text-gray-600">{t.testimonials.testimonial1.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover-lift">
              <CardContent className="p-8">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 text-lg">"{t.testimonials.testimonial2.text}"</p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-semibold mr-4">
                    {t.testimonials.testimonial2.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-semibold">{t.testimonials.testimonial2.name}</div>
                    <div className="text-gray-600">{t.testimonials.testimonial2.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 spiritual-gradient">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white mb-4">{t.cta.title}</h2>
          <p className="text-xl text-white/90 mb-8">{t.cta.subtitle}</p>
          <Link to="/booking">
            <Button size="lg" className="bg-white text-primary hover:bg-gray-100 px-8 py-3">
              {t.cta.button}
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;

