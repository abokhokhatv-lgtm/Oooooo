import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Play, Clock, Users, Star, CheckCircle, Lock, BookOpen, Award, Building2 } from 'lucide-react';
import BankTransferModal from './BankTransferModal';

const CoursesPage = ({ language }) => {
  const [selectedPlan, setSelectedPlan] = useState('monthly');
  const [showBankTransfer, setShowBankTransfer] = useState(false);
  const [transferAmount, setTransferAmount] = useState(0);

  const content = {
    ar: {
      title: 'الكورسات التدريبية',
      subtitle: 'تعلم تقنيات الشفاء الروحاني والتطوير الذاتي من خلال كورساتي المتخصصة',
      membership: {
        title: 'عضوية الكورسات',
        subtitle: 'احصل على وصول كامل لجميع الكورسات والمحتوى الحصري',
        monthly: 'شهري',
        yearly: 'سنوي',
        save: 'وفر 20%',
        features: [
          'وصول لجميع الكورسات',
          'محتوى جديد أسبوعياً',
          'جلسات مباشرة شهرية',
          'مجتمع خاص للأعضاء',
          'شهادات إتمام',
          'دعم فني 24/7'
        ],
        monthlyPrice: '99 جنيه/شهر',
        yearlyPrice: '950 جنيه/سنة',
        subscribe: 'اشترك الآن'
      },
      courses: [
        {
          id: 1,
          title: 'أساسيات الريكي - المستوى الأول',
          description: 'تعلم أساسيات تقنية الريكي للشفاء الذاتي ومساعدة الآخرين',
          duration: '4 أسابيع',
          lessons: 12,
          students: 150,
          rating: 4.9,
          level: 'مبتدئ',
          price: 'مجاني للأعضاء',
          image: '/api/placeholder/300/200',
          features: [
            'تاريخ وفلسفة الريكي',
            'تقنيات الشفاء الأساسية',
            'تطهير الشاكرات',
            'الشفاء الذاتي',
            'شهادة إتمام'
          ]
        },
        {
          id: 2,
          title: 'التأمل العميق والوعي الروحاني',
          description: 'رحلة شاملة لتطوير ممارسة التأمل وزيادة الوعي الروحاني',
          duration: '6 أسابيع',
          lessons: 18,
          students: 200,
          rating: 4.8,
          level: 'متوسط',
          price: 'مجاني للأعضاء',
          image: '/api/placeholder/300/200',
          features: [
            'تقنيات التأمل المختلفة',
            'تطوير الحدس',
            'التواصل مع الذات العليا',
            'تأمل الشاكرات',
            'ممارسات يومية'
          ]
        },
        {
          id: 3,
          title: 'العلاج بالكريستال والأحجار الكريمة',
          description: 'اكتشف قوة الكريستال في الشفاء وتوازن الطاقة',
          duration: '5 أسابيع',
          lessons: 15,
          students: 120,
          rating: 4.7,
          level: 'متوسط',
          price: 'مجاني للأعضاء',
          image: '/api/placeholder/300/200',
          features: [
            'خصائص الكريستال',
            'تقنيات العلاج',
            'تطهير وشحن الأحجار',
            'استخدام الكريستال في التأمل',
            'إنشاء شبكات الطاقة'
          ]
        },
        {
          id: 4,
          title: 'تطوير القدرات الروحانية',
          description: 'تنمية وتطوير قدراتك الروحانية الطبيعية',
          duration: '8 أسابيع',
          lessons: 24,
          students: 80,
          rating: 4.9,
          level: 'متقدم',
          price: 'مجاني للأعضاء',
          image: '/api/placeholder/300/200',
          features: [
            'تطوير الحدس',
            'قراءة الطاقة',
            'التواصل الروحاني',
            'الحماية النفسية',
            'تقنيات متقدمة'
          ]
        }
      ],
      freeCourse: {
        title: 'كورس مجاني: مقدمة في الشفاء الروحاني',
        description: 'ابدأ رحلتك في عالم الشفاء الروحاني مع هذا الكورس المجاني',
        duration: '1 أسبوع',
        lessons: 5,
        startFree: 'ابدأ مجاناً'
      }
    },
    en: {
      title: 'Training Courses',
      subtitle: 'Learn spiritual healing techniques and self-development through my specialized courses',
      membership: {
        title: 'Course Membership',
        subtitle: 'Get full access to all courses and exclusive content',
        monthly: 'Monthly',
        yearly: 'Yearly',
        save: 'Save 20%',
        features: [
          'Access to all courses',
          'New content weekly',
          'Monthly live sessions',
          'Private member community',
          'Completion certificates',
          '24/7 technical support'
        ],
        monthlyPrice: '$12/month',
        yearlyPrice: '$115/year',
        subscribe: 'Subscribe Now'
      },
      courses: [
        {
          id: 1,
          title: 'Reiki Basics - Level One',
          description: 'Learn the fundamentals of Reiki technique for self-healing and helping others',
          duration: '4 weeks',
          lessons: 12,
          students: 150,
          rating: 4.9,
          level: 'Beginner',
          price: 'Free for members',
          image: '/api/placeholder/300/200',
          features: [
            'History and philosophy of Reiki',
            'Basic healing techniques',
            'Chakra cleansing',
            'Self-healing',
            'Completion certificate'
          ]
        },
        {
          id: 2,
          title: 'Deep Meditation and Spiritual Awareness',
          description: 'A comprehensive journey to develop meditation practice and increase spiritual awareness',
          duration: '6 weeks',
          lessons: 18,
          students: 200,
          rating: 4.8,
          level: 'Intermediate',
          price: 'Free for members',
          image: '/api/placeholder/300/200',
          features: [
            'Different meditation techniques',
            'Developing intuition',
            'Connecting with higher self',
            'Chakra meditation',
            'Daily practices'
          ]
        },
        {
          id: 3,
          title: 'Crystal and Gemstone Healing',
          description: 'Discover the power of crystals in healing and energy balance',
          duration: '5 weeks',
          lessons: 15,
          students: 120,
          rating: 4.7,
          level: 'Intermediate',
          price: 'Free for members',
          image: '/api/placeholder/300/200',
          features: [
            'Crystal properties',
            'Healing techniques',
            'Cleansing and charging stones',
            'Using crystals in meditation',
            'Creating energy grids'
          ]
        },
        {
          id: 4,
          title: 'Developing Spiritual Abilities',
          description: 'Nurture and develop your natural spiritual abilities',
          duration: '8 weeks',
          lessons: 24,
          students: 80,
          rating: 4.9,
          level: 'Advanced',
          price: 'Free for members',
          image: '/api/placeholder/300/200',
          features: [
            'Developing intuition',
            'Energy reading',
            'Spiritual communication',
            'Psychic protection',
            'Advanced techniques'
          ]
        }
      ],
      freeCourse: {
        title: 'Free Course: Introduction to Spiritual Healing',
        description: 'Start your journey in the world of spiritual healing with this free course',
        duration: '1 week',
        lessons: 5,
        startFree: 'Start Free'
      }
    }
  };

  const t = content[language];

  const getLevelColor = (level) => {
    const colors = {
      'مبتدئ': 'bg-green-100 text-green-800',
      'متوسط': 'bg-yellow-100 text-yellow-800',
      'متقدم': 'bg-red-100 text-red-800',
      'Beginner': 'bg-green-100 text-green-800',
      'Intermediate': 'bg-yellow-100 text-yellow-800',
      'Advanced': 'bg-red-100 text-red-800'
    };
    return colors[level] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/10 to-secondary/10">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">{t.title}</h1>
          <p className="text-xl text-gray-600">{t.subtitle}</p>
        </div>
      </section>

      {/* Free Course Banner */}
      <section className="py-12 bg-primary">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-white">
            <h2 className="text-3xl font-bold mb-4">{t.freeCourse.title}</h2>
            <p className="text-xl mb-6 opacity-90">{t.freeCourse.description}</p>
            <div className="flex items-center justify-center space-x-6 rtl:space-x-reverse mb-6">
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                {t.freeCourse.duration}
              </div>
              <div className="flex items-center">
                <BookOpen className="h-5 w-5 mr-2" />
                {t.freeCourse.lessons} {language === 'ar' ? 'دروس' : 'lessons'}
              </div>
            </div>
            <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
              {t.freeCourse.startFree}
            </Button>
          </div>
        </div>
      </section>

      {/* Membership Plans */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">{t.membership.title}</h2>
            <p className="text-xl text-gray-600">{t.membership.subtitle}</p>
          </div>

          {/* Plan Toggle */}
          <div className="flex justify-center mb-8">
            <div className="bg-gray-100 p-1 rounded-lg">
              <button
                onClick={() => setSelectedPlan('monthly')}
                className={`px-6 py-2 rounded-md font-medium transition-colors ${
                  selectedPlan === 'monthly'
                    ? 'bg-white text-primary shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {t.membership.monthly}
              </button>
              <button
                onClick={() => setSelectedPlan('yearly')}
                className={`px-6 py-2 rounded-md font-medium transition-colors relative ${
                  selectedPlan === 'yearly'
                    ? 'bg-white text-primary shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {t.membership.yearly}
                <span className="absolute -top-2 -right-2 bg-accent text-white text-xs px-2 py-1 rounded-full">
                  {t.membership.save}
                </span>
              </button>
            </div>
          </div>

          {/* Membership Card */}
          <Card className="max-w-md mx-auto hover-lift">
            <CardContent className="p-8 text-center">
              <div className="mb-6">
                <div className="text-4xl font-bold text-primary mb-2">
                  {selectedPlan === 'monthly' ? t.membership.monthlyPrice : t.membership.yearlyPrice}
                </div>
                {selectedPlan === 'yearly' && (
                  <div className="text-sm text-gray-500 line-through">
                    {language === 'ar' ? '1188 جنيه/سنة' : '$144/year'}
                  </div>
                )}
              </div>

              <ul className="space-y-3 mb-8">
                {t.membership.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-primary mr-3 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="space-y-3">
                <Button className="w-full bg-primary hover:bg-primary/90 py-3">
                  {t.membership.subscribe}
                </Button>
                
                <div className="text-center text-sm text-gray-500">
                  {language === 'ar' ? 'أو' : 'or'}
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full py-3"
                  onClick={() => {
                    setTransferAmount(selectedPlan === 'monthly' ? 99 : 950);
                    setShowBankTransfer(true);
                  }}
                >
                  <Building2 className="h-4 w-4 mr-2" />
                  {language === 'ar' ? 'تحويل بنكي' : 'Bank Transfer'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              {language === 'ar' ? 'الكورسات المتاحة' : 'Available Courses'}
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
            {t.courses.map((course) => (
              <Card key={course.id} className="hover-lift overflow-hidden">
                <div className="aspect-video bg-gray-200 relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                    <Play className="h-16 w-16 text-white bg-black/50 rounded-full p-4" />
                  </div>
                  <div className="absolute top-4 left-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getLevelColor(course.level)}`}>
                      {course.level}
                    </span>
                  </div>
                  <div className="absolute top-4 right-4">
                    <Lock className="h-5 w-5 text-white bg-black/50 rounded p-1" />
                  </div>
                </div>

                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{course.title}</h3>
                  <p className="text-gray-600 mb-4">{course.description}</p>

                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {course.duration}
                    </div>
                    <div className="flex items-center">
                      <BookOpen className="h-4 w-4 mr-1" />
                      {course.lessons} {language === 'ar' ? 'درس' : 'lessons'}
                    </div>
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1" />
                      {course.students}
                    </div>
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 fill-current mr-1" />
                      <span className="font-medium">{course.rating}</span>
                    </div>
                    <div className="text-lg font-bold text-primary">{course.price}</div>
                  </div>

                  <ul className="space-y-2 mb-6">
                    {course.features.slice(0, 3).map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <CheckCircle className="h-4 w-4 text-primary mr-2 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button className="w-full bg-primary hover:bg-primary/90">
                    {language === 'ar' ? 'ابدأ الكورس' : 'Start Course'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              {language === 'ar' ? 'لماذا تختار كورساتي؟' : 'Why Choose My Courses?'}
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <Award className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">
                {language === 'ar' ? 'شهادات معتمدة' : 'Certified Courses'}
              </h3>
              <p className="text-gray-600">
                {language === 'ar' 
                  ? 'احصل على شهادات معتمدة عند إتمام الكورسات'
                  : 'Get certified certificates upon course completion'
                }
              </p>
            </div>

            <div className="text-center">
              <Users className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">
                {language === 'ar' ? 'مجتمع داعم' : 'Supportive Community'}
              </h3>
              <p className="text-gray-600">
                {language === 'ar' 
                  ? 'انضم لمجتمع من المتعلمين المتشابهين في التفكير'
                  : 'Join a community of like-minded learners'
                }
              </p>
            </div>

            <div className="text-center">
              <Play className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">
                {language === 'ar' ? 'تعلم بالسرعة التي تناسبك' : 'Learn at Your Own Pace'}
              </h3>
              <p className="text-gray-600">
                {language === 'ar' 
                  ? 'وصول مدى الحياة للمحتوى مع مرونة في التعلم'
                  : 'Lifetime access to content with flexible learning'
                }
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Bank Transfer Modal */}
      <BankTransferModal
        isOpen={showBankTransfer}
        onClose={() => setShowBankTransfer(false)}
        amount={transferAmount}
        currency="EGP"
        language={language}
        onConfirm={() => {
          // Handle confirmation logic here
          console.log('Bank transfer confirmed');
        }}
      />
    </div>
  );
};

export default CoursesPage;

