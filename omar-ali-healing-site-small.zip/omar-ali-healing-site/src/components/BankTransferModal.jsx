import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  X, 
  Copy, 
  Check, 
  Building2, 
  User, 
  CreditCard, 
  Globe,
  Mail,
  MessageCircle,
  Clock,
  CheckCircle
} from 'lucide-react';

const BankTransferModal = ({ isOpen, onClose, amount, currency, language = 'ar', onConfirm }) => {
  const [copied, setCopied] = useState({});
  const [confirmed, setConfirmed] = useState(false);

  const content = {
    ar: {
      title: 'بيانات التحويل البنكي',
      subtitle: `المبلغ المطلوب: ${amount} ${currency}`,
      bankDetails: {
        title: '💳 بيانات التحويل البنكي:',
        bankName: 'اسم البنك',
        accountName: 'اسم الحساب',
        accountNumber: 'رقم الحساب',
        iban: 'IBAN',
        bankNameValue: 'البنك الأهلي المصري',
        accountNameValue: 'Omar Ali',
        accountNumberValue: '1234567890123456',
        ibanValue: 'EG380002001234567890123456'
      },
      steps: {
        title: 'الخطوات بعد التحويل:',
        step1: 'التقط صورة إيصال التحويل أو سجل رقم العملية.',
        step2: 'أرسلها عبر البريد الإلكتروني: abokhokhatv@gmail.com',
        step3: 'أو عبر واتساب: +201234567890',
        step4: 'سيتم تفعيل اشتراكك/حجزك يدويًا خلال 24 ساعة.'
      },
      buttons: {
        copy: 'نسخ',
        copied: 'تم النسخ',
        sendEmail: 'إرسال إيميل',
        sendWhatsApp: 'إرسال واتساب',
        confirm: 'تأكيد التحويل',
        close: 'إغلاق'
      },
      confirmation: {
        title: 'شكرًا لاختيارك الدفع البنكي 🌿',
        message: 'بيانات الحساب تم إرسالها إلى بريدك الإلكتروني. تواصل معنا بعد التحويل وسيتم تفعيل اشتراكك خلال 24 ساعة.',
        note: 'ملاحظة: احتفظ بإيصال التحويل لحين تأكيد العملية.'
      }
    },
    en: {
      title: 'Bank Transfer Details',
      subtitle: `Amount Required: ${amount} ${currency}`,
      bankDetails: {
        title: '💳 Bank Transfer Details:',
        bankName: 'Bank Name',
        accountName: 'Account Name',
        accountNumber: 'Account Number',
        iban: 'IBAN',
        bankNameValue: 'National Bank of Egypt',
        accountNameValue: 'Omar Ali',
        accountNumberValue: '1234567890123456',
        ibanValue: 'EG380002001234567890123456'
      },
      steps: {
        title: 'Steps After Transfer:',
        step1: 'Take a photo of the transfer receipt or record the transaction number.',
        step2: 'Send it via email: abokhokhatv@gmail.com',
        step3: 'Or via WhatsApp: +201234567890',
        step4: 'Your subscription/booking will be activated manually within 24 hours.'
      },
      buttons: {
        copy: 'Copy',
        copied: 'Copied',
        sendEmail: 'Send Email',
        sendWhatsApp: 'Send WhatsApp',
        confirm: 'Confirm Transfer',
        close: 'Close'
      },
      confirmation: {
        title: 'Thank you for choosing bank transfer 🌿',
        message: 'Account details have been sent to your email. Contact us after the transfer and your subscription will be activated within 24 hours.',
        note: 'Note: Keep the transfer receipt until the transaction is confirmed.'
      }
    }
  };

  const t = content[language];

  const copyToClipboard = (text, field) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied({ ...copied, [field]: true });
      setTimeout(() => {
        setCopied({ ...copied, [field]: false });
      }, 2000);
    });
  };

  const handleSendEmail = () => {
    const subject = encodeURIComponent(`Bank Transfer - ${amount} ${currency}`);
    const body = encodeURIComponent(`
Hello Omar Ali,

I have completed a bank transfer for ${amount} ${currency}.

Bank Details Used:
- Bank: ${t.bankDetails.bankNameValue}
- Account: ${t.bankDetails.accountNameValue}
- Account Number: ${t.bankDetails.accountNumberValue}
- IBAN: ${t.bankDetails.ibanValue}

Please find the transfer receipt attached.

Best regards
    `);
    window.open(`mailto:abokhokhatv@gmail.com?subject=${subject}&body=${body}`);
  };

  const handleSendWhatsApp = () => {
    const message = encodeURIComponent(`
Hello Omar Ali,

I have completed a bank transfer for ${amount} ${currency}.

Bank Details Used:
- Bank: ${t.bankDetails.bankNameValue}
- Account: ${t.bankDetails.accountNameValue}
- Account Number: ${t.bankDetails.accountNumberValue}

I will send the transfer receipt shortly.

Thank you
    `);
    window.open(`https://wa.me/201234567890?text=${message}`);
  };

  const handleConfirm = () => {
    setConfirmed(true);
    setTimeout(() => {
      onConfirm && onConfirm();
      onClose();
    }, 3000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {!confirmed ? (
          <>
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-2xl font-bold text-gray-900">{t.title}</h2>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Amount */}
              <div className="text-center">
                <div className="text-lg font-medium text-primary">{t.subtitle}</div>
              </div>

              {/* Bank Details */}
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-lg text-primary flex items-center">
                    <Building2 className="h-5 w-5 mr-2" />
                    {t.bankDetails.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Bank Name */}
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3 rtl:space-x-reverse">
                      <Building2 className="h-5 w-5 text-primary" />
                      <div>
                        <div className="text-sm text-gray-600">{t.bankDetails.bankName}</div>
                        <div className="font-medium">{t.bankDetails.bankNameValue}</div>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(t.bankDetails.bankNameValue, 'bankName')}
                    >
                      {copied.bankName ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      {copied.bankName ? t.buttons.copied : t.buttons.copy}
                    </Button>
                  </div>

                  {/* Account Name */}
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3 rtl:space-x-reverse">
                      <User className="h-5 w-5 text-primary" />
                      <div>
                        <div className="text-sm text-gray-600">{t.bankDetails.accountName}</div>
                        <div className="font-medium">{t.bankDetails.accountNameValue}</div>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(t.bankDetails.accountNameValue, 'accountName')}
                    >
                      {copied.accountName ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      {copied.accountName ? t.buttons.copied : t.buttons.copy}
                    </Button>
                  </div>

                  {/* Account Number */}
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3 rtl:space-x-reverse">
                      <CreditCard className="h-5 w-5 text-primary" />
                      <div>
                        <div className="text-sm text-gray-600">{t.bankDetails.accountNumber}</div>
                        <div className="font-medium font-mono">{t.bankDetails.accountNumberValue}</div>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(t.bankDetails.accountNumberValue, 'accountNumber')}
                    >
                      {copied.accountNumber ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      {copied.accountNumber ? t.buttons.copied : t.buttons.copy}
                    </Button>
                  </div>

                  {/* IBAN */}
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3 rtl:space-x-reverse">
                      <Globe className="h-5 w-5 text-primary" />
                      <div>
                        <div className="text-sm text-gray-600">{t.bankDetails.iban}</div>
                        <div className="font-medium font-mono">{t.bankDetails.ibanValue}</div>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(t.bankDetails.ibanValue, 'iban')}
                    >
                      {copied.iban ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      {copied.iban ? t.buttons.copied : t.buttons.copy}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Steps */}
              <Card className="border-2 border-blue-200">
                <CardHeader>
                  <CardTitle className="text-lg text-blue-600 flex items-center">
                    <Clock className="h-5 w-5 mr-2" />
                    {t.steps.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start space-x-3 rtl:space-x-reverse">
                    <div className="bg-blue-100 text-blue-600 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">1</div>
                    <p className="text-gray-700">{t.steps.step1}</p>
                  </div>
                  <div className="flex items-start space-x-3 rtl:space-x-reverse">
                    <div className="bg-blue-100 text-blue-600 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">2</div>
                    <p className="text-gray-700">{t.steps.step2}</p>
                  </div>
                  <div className="flex items-start space-x-3 rtl:space-x-reverse">
                    <div className="bg-blue-100 text-blue-600 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">3</div>
                    <p className="text-gray-700">{t.steps.step3}</p>
                  </div>
                  <div className="flex items-start space-x-3 rtl:space-x-reverse">
                    <div className="bg-blue-100 text-blue-600 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">4</div>
                    <p className="text-gray-700">{t.steps.step4}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  onClick={handleSendEmail}
                  className="flex-1 bg-blue-500 hover:bg-blue-600 text-white"
                >
                  <Mail className="h-4 w-4 mr-2" />
                  {t.buttons.sendEmail}
                </Button>
                <Button
                  onClick={handleSendWhatsApp}
                  className="flex-1 bg-green-500 hover:bg-green-600 text-white"
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  {t.buttons.sendWhatsApp}
                </Button>
              </div>

              {/* Confirm Button */}
              <div className="flex gap-3">
                <Button
                  onClick={handleConfirm}
                  className="flex-1 bg-primary hover:bg-primary/90 text-white"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  {t.buttons.confirm}
                </Button>
                <Button
                  onClick={onClose}
                  variant="outline"
                  className="px-6"
                >
                  {t.buttons.close}
                </Button>
              </div>
            </div>
          </>
        ) : (
          /* Confirmation Screen */
          <div className="p-8 text-center">
            <div className="mb-6">
              <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-8 w-8 text-green-500" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                {t.confirmation.title}
              </h3>
              <p className="text-gray-600 mb-4">
                {t.confirmation.message}
              </p>
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-sm text-yellow-800">
                  {t.confirmation.note}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BankTransferModal;

