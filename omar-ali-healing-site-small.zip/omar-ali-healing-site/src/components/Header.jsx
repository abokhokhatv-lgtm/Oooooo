import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Menu, X, Globe } from 'lucide-react';
import logoImage from '../assets/logo_omar_ali.png';

const Header = ({ language, toggleLanguage }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const content = {
    ar: {
      home: 'الرئيسية',
      about: 'من أنا',
      services: 'الخدمات',
      courses: 'الكورسات',
      blog: 'المدونة',
      contact: 'التواصل',
      booking: 'حجز موعد',
      name: 'عمر علي',
      tagline: 'المعالج الروحاني'
    },
    en: {
      home: 'Home',
      about: 'About',
      services: 'Services',
      courses: 'Courses',
      blog: 'Blog',
      contact: 'Contact',
      booking: 'Book Session',
      name: 'Omar Ali',
      tagline: 'Spiritual Healer'
    }
  };

  const t = content[language];

  const navItems = [
    { key: 'home', path: '/' },
    { key: 'about', path: '/about' },
    { key: 'services', path: '/services' },
    { key: 'courses', path: '/courses' },
    { key: 'blog', path: '/blog' },
    { key: 'contact', path: '/contact' }
  ];

  return (
    <header className="bg-white/95 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3 rtl:space-x-reverse">
            <img src={logoImage} alt="Omar Ali Logo" className="h-10 w-10" />
            <div className="flex flex-col">
              <span className="text-xl font-bold text-primary">{t.name}</span>
              <span className="text-sm text-muted-foreground">{t.tagline}</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8 rtl:space-x-reverse">
            {navItems.map((item) => (
              <Link
                key={item.key}
                to={item.path}
                className="text-gray-700 hover:text-primary transition-colors duration-200 font-medium"
              >
                {t[item.key]}
              </Link>
            ))}
          </nav>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            {/* Language Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleLanguage}
              className="flex items-center space-x-2 rtl:space-x-reverse"
            >
              <Globe className="h-4 w-4" />
              <span>{language === 'ar' ? 'EN' : 'عر'}</span>
            </Button>

            {/* Book Session Button */}
            <Link to="/booking">
              <Button className="hidden md:inline-flex bg-primary hover:bg-primary/90">
                {t.booking}
              </Button>
            </Link>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-3">
              {navItems.map((item) => (
                <Link
                  key={item.key}
                  to={item.path}
                  className="text-gray-700 hover:text-primary transition-colors duration-200 font-medium py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {t[item.key]}
                </Link>
              ))}
              <Link to="/booking" onClick={() => setIsMenuOpen(false)}>
                <Button className="w-full mt-4 bg-primary hover:bg-primary/90">
                  {t.booking}
                </Button>
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;

