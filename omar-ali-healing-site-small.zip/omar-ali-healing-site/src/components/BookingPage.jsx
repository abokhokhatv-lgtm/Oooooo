import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Calendar, Clock, User, Phone, Mail, CreditCard, CheckCircle } from 'lucide-react';

const BookingPage = ({ language }) => {
  const [selectedService, setSelectedService] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    notes: ''
  });

  const content = {
    ar: {
      title: 'حجز موعد',
      subtitle: 'احجز جلستك الروحانية واختر الوقت المناسب لك',
      steps: {
        1: 'اختر الخدمة',
        2: 'اختر التاريخ والوقت',
        3: 'معلوماتك الشخصية',
        4: 'الدفع والتأكيد'
      },
      services: [
        {
          id: 'healing',
          name: 'جلسة علاج روحاني',
          duration: '60-90 دقيقة',
          price: '200 جنيه',
          description: 'جلسة فردية لتطهير الطاقة السلبية وتحقيق التوازن الداخلي'
        },
        {
          id: 'consultation',
          name: 'استشارة روحانية',
          duration: '45 دقيقة',
          price: '150 جنيه',
          description: 'إرشاد روحاني لاتخاذ القرارات المهمة في حياتك'
        },
        {
          id: 'distance',
          name: 'جلسة عن بُعد',
          duration: '45-60 دقيقة',
          price: '180 جنيه',
          description: 'جلسة شفاء روحاني عبر الإنترنت'
        }
      ],
      availableTimes: [
        '09:00', '10:30', '12:00', '13:30', '15:00', '16:30', '18:00'
      ],
      form: {
        name: 'الاسم الكامل',
        email: 'البريد الإلكتروني',
        phone: 'رقم الهاتف',
        notes: 'ملاحظات إضافية',
        namePlaceholder: 'أدخل اسمك الكامل',
        emailPlaceholder: 'أدخل بريدك الإلكتروني',
        phonePlaceholder: 'أدخل رقم هاتفك',
        notesPlaceholder: 'أي ملاحظات أو طلبات خاصة...'
      },
      payment: {
        title: 'طرق الدفع',
        methods: [
          { id: 'card', name: 'بطاقة ائتمان', icon: CreditCard },
          { id: 'fawry', name: 'فوري', icon: Phone },
          { id: 'vodafone', name: 'فودافون كاش', icon: Phone }
        ]
      },
      buttons: {
        next: 'التالي',
        back: 'السابق',
        confirm: 'تأكيد الحجز',
        selectService: 'اختر هذه الخدمة',
        selectTime: 'اختر هذا الوقت'
      },
      confirmation: {
        title: 'تم تأكيد حجزك بنجاح!',
        subtitle: 'سيتم إرسال تفاصيل الموعد إلى بريدك الإلكتروني',
        details: 'تفاصيل الحجز',
        service: 'الخدمة',
        date: 'التاريخ',
        time: 'الوقت',
        price: 'السعر'
      }
    },
    en: {
      title: 'Book Appointment',
      subtitle: 'Book your spiritual session and choose the time that suits you',
      steps: {
        1: 'Choose Service',
        2: 'Select Date & Time',
        3: 'Your Information',
        4: 'Payment & Confirmation'
      },
      services: [
        {
          id: 'healing',
          name: 'Spiritual Healing Session',
          duration: '60-90 minutes',
          price: '$25',
          description: 'Individual session to cleanse negative energy and achieve inner balance'
        },
        {
          id: 'consultation',
          name: 'Spiritual Consultation',
          duration: '45 minutes',
          price: '$20',
          description: 'Spiritual guidance for making important life decisions'
        },
        {
          id: 'distance',
          name: 'Remote Session',
          duration: '45-60 minutes',
          price: '$22',
          description: 'Online spiritual healing session'
        }
      ],
      availableTimes: [
        '09:00', '10:30', '12:00', '13:30', '15:00', '16:30', '18:00'
      ],
      form: {
        name: 'Full Name',
        email: 'Email Address',
        phone: 'Phone Number',
        notes: 'Additional Notes',
        namePlaceholder: 'Enter your full name',
        emailPlaceholder: 'Enter your email address',
        phonePlaceholder: 'Enter your phone number',
        notesPlaceholder: 'Any notes or special requests...'
      },
      payment: {
        title: 'Payment Methods',
        methods: [
          { id: 'card', name: 'Credit Card', icon: CreditCard },
          { id: 'paypal', name: 'PayPal', icon: CreditCard },
          { id: 'stripe', name: 'Stripe', icon: CreditCard }
        ]
      },
      buttons: {
        next: 'Next',
        back: 'Back',
        confirm: 'Confirm Booking',
        selectService: 'Select This Service',
        selectTime: 'Select This Time'
      },
      confirmation: {
        title: 'Your booking has been confirmed successfully!',
        subtitle: 'Appointment details will be sent to your email',
        details: 'Booking Details',
        service: 'Service',
        date: 'Date',
        time: 'Time',
        price: 'Price'
      }
    }
  };

  const t = content[language];

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const nextStep = () => {
    if (step < 4) setStep(step + 1);
  };

  const prevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  const getSelectedService = () => {
    return t.services.find(service => service.id === selectedService);
  };

  // Generate next 14 days for date selection
  const getAvailableDates = () => {
    const dates = [];
    const today = new Date();
    for (let i = 1; i <= 14; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      dates.push(date);
    }
    return dates;
  };

  const formatDate = (date) => {
    return date.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (step === 4 && selectedService && selectedDate && selectedTime) {
    return (
      <div className="min-h-screen pt-16 bg-gray-50">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <Card className="text-center">
            <CardContent className="p-12">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-6" />
              <h1 className="text-3xl font-bold text-gray-900 mb-4">{t.confirmation.title}</h1>
              <p className="text-gray-600 mb-8">{t.confirmation.subtitle}</p>
              
              <div className="bg-gray-50 rounded-lg p-6 mb-8">
                <h3 className="text-lg font-semibold mb-4">{t.confirmation.details}</h3>
                <div className="space-y-3 text-left">
                  <div className="flex justify-between">
                    <span className="text-gray-600">{t.confirmation.service}:</span>
                    <span className="font-medium">{getSelectedService()?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">{t.confirmation.date}:</span>
                    <span className="font-medium">{formatDate(new Date(selectedDate))}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">{t.confirmation.time}:</span>
                    <span className="font-medium">{selectedTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">{t.confirmation.price}:</span>
                    <span className="font-medium">{getSelectedService()?.price}</span>
                  </div>
                </div>
              </div>
              
              <Button onClick={() => window.location.href = '/'} className="bg-primary hover:bg-primary/90">
                {language === 'ar' ? 'العودة للرئيسية' : 'Back to Home'}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/10 to-secondary/10">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">{t.title}</h1>
          <p className="text-xl text-gray-600">{t.subtitle}</p>
        </div>
      </section>

      {/* Progress Steps */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {[1, 2, 3, 4].map((stepNumber) => (
              <div key={stepNumber} className="flex items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                  step >= stepNumber ? 'bg-primary text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {stepNumber}
                </div>
                <span className={`ml-3 font-medium ${
                  step >= stepNumber ? 'text-primary' : 'text-gray-600'
                }`}>
                  {t.steps[stepNumber]}
                </span>
                {stepNumber < 4 && (
                  <div className={`w-16 h-1 mx-4 ${
                    step > stepNumber ? 'bg-primary' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Step Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Step 1: Choose Service */}
          {step === 1 && (
            <div>
              <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">{t.steps[1]}</h2>
              <div className="grid md:grid-cols-3 gap-6">
                {t.services.map((service) => (
                  <Card key={service.id} className={`hover-lift cursor-pointer transition-all ${
                    selectedService === service.id ? 'ring-2 ring-primary' : ''
                  }`}>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-3">{service.name}</h3>
                      <p className="text-gray-600 mb-4">{service.description}</p>
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center text-gray-500">
                          <Clock className="h-4 w-4 mr-1" />
                          {service.duration}
                        </div>
                        <div className="text-2xl font-bold text-primary">{service.price}</div>
                      </div>
                      <Button 
                        onClick={() => setSelectedService(service.id)}
                        className={`w-full ${
                          selectedService === service.id 
                            ? 'bg-primary hover:bg-primary/90' 
                            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                        }`}
                      >
                        {t.buttons.selectService}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
              <div className="text-center mt-8">
                <Button 
                  onClick={nextStep} 
                  disabled={!selectedService}
                  className="bg-primary hover:bg-primary/90 px-8"
                >
                  {t.buttons.next}
                </Button>
              </div>
            </div>
          )}

          {/* Step 2: Choose Date & Time */}
          {step === 2 && (
            <div>
              <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">{t.steps[2]}</h2>
              
              {/* Date Selection */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold mb-4">{language === 'ar' ? 'اختر التاريخ' : 'Choose Date'}</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
                  {getAvailableDates().map((date, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedDate(date.toISOString().split('T')[0])}
                      className={`p-3 rounded-lg border text-center transition-colors ${
                        selectedDate === date.toISOString().split('T')[0]
                          ? 'bg-primary text-white border-primary'
                          : 'bg-white border-gray-300 hover:border-primary'
                      }`}
                    >
                      <div className="font-medium">{date.getDate()}</div>
                      <div className="text-sm">
                        {date.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', { weekday: 'short' })}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Time Selection */}
              {selectedDate && (
                <div className="mb-8">
                  <h3 className="text-xl font-semibold mb-4">{language === 'ar' ? 'اختر الوقت' : 'Choose Time'}</h3>
                  <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3">
                    {t.availableTimes.map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`p-3 rounded-lg border text-center transition-colors ${
                          selectedTime === time
                            ? 'bg-primary text-white border-primary'
                            : 'bg-white border-gray-300 hover:border-primary'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-between">
                <Button onClick={prevStep} variant="outline">
                  {t.buttons.back}
                </Button>
                <Button 
                  onClick={nextStep} 
                  disabled={!selectedDate || !selectedTime}
                  className="bg-primary hover:bg-primary/90"
                >
                  {t.buttons.next}
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Personal Information */}
          {step === 3 && (
            <div>
              <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">{t.steps[3]}</h2>
              <Card className="max-w-2xl mx-auto">
                <CardContent className="p-8">
                  <form className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t.form.name}
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder={t.form.namePlaceholder}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t.form.email}
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder={t.form.emailPlaceholder}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t.form.phone}
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder={t.form.phonePlaceholder}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t.form.notes}
                      </label>
                      <textarea
                        name="notes"
                        value={formData.notes}
                        onChange={handleInputChange}
                        placeholder={t.form.notesPlaceholder}
                        rows={4}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                      />
                    </div>
                  </form>
                </CardContent>
              </Card>

              <div className="flex justify-between mt-8">
                <Button onClick={prevStep} variant="outline">
                  {t.buttons.back}
                </Button>
                <Button 
                  onClick={nextStep} 
                  disabled={!formData.name || !formData.email || !formData.phone}
                  className="bg-primary hover:bg-primary/90"
                >
                  {t.buttons.next}
                </Button>
              </div>
            </div>
          )}

          {/* Step 4: Payment & Confirmation */}
          {step === 4 && (
            <div>
              <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">{t.steps[4]}</h2>
              
              <div className="grid lg:grid-cols-2 gap-8">
                {/* Booking Summary */}
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold mb-4">{language === 'ar' ? 'ملخص الحجز' : 'Booking Summary'}</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">{t.confirmation.service}:</span>
                        <span className="font-medium">{getSelectedService()?.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">{t.confirmation.date}:</span>
                        <span className="font-medium">{formatDate(new Date(selectedDate))}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">{t.confirmation.time}:</span>
                        <span className="font-medium">{selectedTime}</span>
                      </div>
                      <div className="flex justify-between border-t pt-3">
                        <span className="text-gray-600">{t.confirmation.price}:</span>
                        <span className="text-2xl font-bold text-primary">{getSelectedService()?.price}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Payment Methods */}
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold mb-4">{t.payment.title}</h3>
                    <div className="space-y-3">
                      {t.payment.methods.map((method) => (
                        <button
                          key={method.id}
                          className="w-full p-4 border border-gray-300 rounded-lg hover:border-primary transition-colors flex items-center"
                        >
                          <method.icon className="h-6 w-6 text-gray-600 mr-3" />
                          <span className="font-medium">{method.name}</span>
                        </button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="flex justify-between mt-8">
                <Button onClick={prevStep} variant="outline">
                  {t.buttons.back}
                </Button>
                <Button 
                  onClick={() => setStep(4)} 
                  className="bg-primary hover:bg-primary/90"
                >
                  {t.buttons.confirm}
                </Button>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default BookingPage;

