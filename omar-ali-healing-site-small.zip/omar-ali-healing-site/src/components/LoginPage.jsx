import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Eye, EyeOff, Mail, Lock, User, Phone } from 'lucide-react';

const LoginPage = ({ language, onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    username: '',
    first_name: '',
    last_name: '',
    phone: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState({});

  const content = {
    ar: {
      login: {
        title: 'تسجيل الدخول',
        subtitle: 'مرحباً بعودتك! سجل دخولك للوصول لحسابك',
        email: 'البريد الإلكتروني',
        password: 'كلمة المرور',
        loginButton: 'تسجيل الدخول',
        forgotPassword: 'نسيت كلمة المرور؟',
        noAccount: 'ليس لديك حساب؟',
        signUp: 'إنشاء حساب جديد'
      },
      register: {
        title: 'إنشاء حساب جديد',
        subtitle: 'انضم إلينا وابدأ رحلتك الروحانية',
        username: 'اسم المستخدم',
        firstName: 'الاسم الأول',
        lastName: 'اسم العائلة',
        email: 'البريد الإلكتروني',
        phone: 'رقم الهاتف',
        password: 'كلمة المرور',
        confirmPassword: 'تأكيد كلمة المرور',
        registerButton: 'إنشاء الحساب',
        haveAccount: 'لديك حساب بالفعل؟',
        signIn: 'تسجيل الدخول'
      },
      placeholders: {
        email: 'أدخل بريدك الإلكتروني',
        password: 'أدخل كلمة المرور',
        username: 'أدخل اسم المستخدم',
        firstName: 'أدخل اسمك الأول',
        lastName: 'أدخل اسم العائلة',
        phone: 'أدخل رقم هاتفك',
        confirmPassword: 'أعد إدخال كلمة المرور'
      },
      errors: {
        required: 'هذا الحقل مطلوب',
        invalidEmail: 'البريد الإلكتروني غير صحيح',
        passwordMismatch: 'كلمات المرور غير متطابقة',
        minLength: 'يجب أن تكون كلمة المرور 8 أحرف على الأقل'
      }
    },
    en: {
      login: {
        title: 'Sign In',
        subtitle: 'Welcome back! Please sign in to your account',
        email: 'Email Address',
        password: 'Password',
        loginButton: 'Sign In',
        forgotPassword: 'Forgot Password?',
        noAccount: "Don't have an account?",
        signUp: 'Sign Up'
      },
      register: {
        title: 'Create Account',
        subtitle: 'Join us and start your spiritual journey',
        username: 'Username',
        firstName: 'First Name',
        lastName: 'Last Name',
        email: 'Email Address',
        phone: 'Phone Number',
        password: 'Password',
        confirmPassword: 'Confirm Password',
        registerButton: 'Create Account',
        haveAccount: 'Already have an account?',
        signIn: 'Sign In'
      },
      placeholders: {
        email: 'Enter your email',
        password: 'Enter your password',
        username: 'Enter username',
        firstName: 'Enter first name',
        lastName: 'Enter last name',
        phone: 'Enter phone number',
        confirmPassword: 'Confirm your password'
      },
      errors: {
        required: 'This field is required',
        invalidEmail: 'Invalid email address',
        passwordMismatch: 'Passwords do not match',
        minLength: 'Password must be at least 8 characters'
      }
    }
  };

  const t = content[language];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (isLogin) {
      // Login validation
      if (!formData.email) {
        newErrors.email = t.errors.required;
      } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
        newErrors.email = t.errors.invalidEmail;
      }

      if (!formData.password) {
        newErrors.password = t.errors.required;
      }
    } else {
      // Registration validation
      if (!formData.username) {
        newErrors.username = t.errors.required;
      }

      if (!formData.first_name) {
        newErrors.first_name = t.errors.required;
      }

      if (!formData.last_name) {
        newErrors.last_name = t.errors.required;
      }

      if (!formData.email) {
        newErrors.email = t.errors.required;
      } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
        newErrors.email = t.errors.invalidEmail;
      }

      if (!formData.password) {
        newErrors.password = t.errors.required;
      } else if (formData.password.length < 8) {
        newErrors.password = t.errors.minLength;
      }

      if (!formData.confirmPassword) {
        newErrors.confirmPassword = t.errors.required;
      } else if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = t.errors.passwordMismatch;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register';
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          email: formData.email,
          password: formData.password,
          ...(isLogin ? {} : {
            username: formData.username,
            first_name: formData.first_name,
            last_name: formData.last_name,
            phone: formData.phone,
            language_preference: language
          })
        }),
      });

      const data = await response.json();

      if (response.ok) {
        // Success
        if (onLogin) {
          onLogin(data.user);
        }
        // Redirect or update UI
        window.location.href = data.user.role === 'admin' ? '/admin' : '/';
      } else {
        // Error
        setErrors({ general: data.error || 'An error occurred' });
      }
    } catch (error) {
      setErrors({ general: 'Network error. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const InputField = ({ 
    name, 
    type = 'text', 
    placeholder, 
    icon: Icon, 
    required = false 
  }) => (
    <div className="space-y-2">
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Icon className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type={type === 'password' && showPassword ? 'text' : type}
          name={name}
          value={formData[name]}
          onChange={handleInputChange}
          placeholder={placeholder}
          required={required}
          className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent ${
            errors[name] ? 'border-red-500' : 'border-gray-300'
          }`}
        />
        {type === 'password' && (
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute inset-y-0 right-0 pr-3 flex items-center"
          >
            {showPassword ? (
              <EyeOff className="h-5 w-5 text-gray-400" />
            ) : (
              <Eye className="h-5 w-5 text-gray-400" />
            )}
          </button>
        )}
      </div>
      {errors[name] && (
        <p className="text-red-500 text-sm">{errors[name]}</p>
      )}
    </div>
  );

  return (
    <div className="min-h-screen pt-16 bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center">
      <div className="max-w-md w-full mx-4">
        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-gray-900">
              {isLogin ? t.login.title : t.register.title}
            </CardTitle>
            <p className="text-gray-600 mt-2">
              {isLogin ? t.login.subtitle : t.register.subtitle}
            </p>
          </CardHeader>
          
          <CardContent className="p-6">
            {errors.general && (
              <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
                {errors.general}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <>
                  <InputField
                    name="username"
                    placeholder={t.placeholders.username}
                    icon={User}
                    required
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <InputField
                      name="first_name"
                      placeholder={t.placeholders.firstName}
                      icon={User}
                      required
                    />
                    <InputField
                      name="last_name"
                      placeholder={t.placeholders.lastName}
                      icon={User}
                      required
                    />
                  </div>

                  <InputField
                    name="phone"
                    type="tel"
                    placeholder={t.placeholders.phone}
                    icon={Phone}
                  />
                </>
              )}

              <InputField
                name="email"
                type="email"
                placeholder={t.placeholders.email}
                icon={Mail}
                required
              />

              <InputField
                name="password"
                type="password"
                placeholder={t.placeholders.password}
                icon={Lock}
                required
              />

              {!isLogin && (
                <InputField
                  name="confirmPassword"
                  type="password"
                  placeholder={t.placeholders.confirmPassword}
                  icon={Lock}
                  required
                />
              )}

              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90 py-3"
                disabled={loading}
              >
                {loading ? (
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
                  </div>
                ) : (
                  isLogin ? t.login.loginButton : t.register.registerButton
                )}
              </Button>
            </form>

            {isLogin && (
              <div className="text-center mt-4">
                <a href="#" className="text-primary hover:text-primary/80 text-sm">
                  {t.login.forgotPassword}
                </a>
              </div>
            )}

            <div className="text-center mt-6 pt-6 border-t border-gray-200">
              <p className="text-gray-600">
                {isLogin ? t.login.noAccount : t.register.haveAccount}
              </p>
              <button
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setFormData({
                    email: '',
                    password: '',
                    username: '',
                    first_name: '',
                    last_name: '',
                    phone: '',
                    confirmPassword: ''
                  });
                  setErrors({});
                }}
                className="text-primary hover:text-primary/80 font-medium mt-1"
              >
                {isLogin ? t.login.signUp : t.register.signIn}
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LoginPage;

