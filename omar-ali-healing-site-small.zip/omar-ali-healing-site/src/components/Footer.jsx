import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Mail, Phone, MapPin } from 'lucide-react';
import logoImage from '../assets/logo_omar_ali.png';

const Footer = ({ language }) => {
  const content = {
    ar: {
      name: 'عمر علي',
      tagline: 'المعالج الروحاني',
      description: 'أساعدك في اكتشاف قوة الطاقة الداخلية وتحقيق التوازن في حياتك من خلال تقنيات الشفاء الروحاني المتقدمة.',
      quickLinks: 'روابط سريعة',
      services: 'الخدمات',
      contact: 'معلومات التواصل',
      newsletter: 'النشرة البريدية',
      newsletterText: 'اشترك في نشرتنا البريدية للحصول على آخر النصائح والمقالات الروحانية',
      subscribe: 'اشتراك',
      emailPlaceholder: 'أدخل بريدك الإلكتروني',
      rights: 'جميع الحقوق محفوظة',
      privacy: 'سياسة الخصوصية',
      terms: 'الشروط والأحكام',
      links: {
        home: 'الرئيسية',
        about: 'من أنا',
        services: 'الخدمات',
        courses: 'الكورسات',
        blog: 'المدونة',
        contact: 'التواصل'
      },
      servicesList: {
        healing: 'جلسات العلاج الروحاني',
        consultation: 'الاستشارات الروحانية',
        workshops: 'الورش التدريبية',
        courses: 'الكورسات التدريبية'
      }
    },
    en: {
      name: 'Omar Ali',
      tagline: 'Spiritual Healer',
      description: 'I help you discover the power of inner energy and achieve balance in your life through advanced spiritual healing techniques.',
      quickLinks: 'Quick Links',
      services: 'Services',
      contact: 'Contact Info',
      newsletter: 'Newsletter',
      newsletterText: 'Subscribe to our newsletter to get the latest spiritual tips and articles',
      subscribe: 'Subscribe',
      emailPlaceholder: 'Enter your email',
      rights: 'All rights reserved',
      privacy: 'Privacy Policy',
      terms: 'Terms & Conditions',
      links: {
        home: 'Home',
        about: 'About',
        services: 'Services',
        courses: 'Courses',
        blog: 'Blog',
        contact: 'Contact'
      },
      servicesList: {
        healing: 'Spiritual Healing Sessions',
        consultation: 'Spiritual Consultations',
        workshops: 'Training Workshops',
        courses: 'Training Courses'
      }
    }
  };

  const t = content[language];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 rtl:space-x-reverse mb-4">
              <img src={logoImage} alt="Omar Ali Logo" className="h-10 w-10" />
              <div className="flex flex-col">
                <span className="text-xl font-bold text-white">{t.name}</span>
                <span className="text-sm text-gray-400">{t.tagline}</span>
              </div>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              {t.description}
            </p>
            <div className="flex space-x-4 rtl:space-x-reverse">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="mailto:info@omarali.com" className="text-gray-400 hover:text-white transition-colors">
                <Mail className="h-6 w-6" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">{t.quickLinks}</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-white transition-colors">{t.links.home}</Link></li>
              <li><Link to="/about" className="text-gray-400 hover:text-white transition-colors">{t.links.about}</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white transition-colors">{t.links.services}</Link></li>
              <li><Link to="/courses" className="text-gray-400 hover:text-white transition-colors">{t.links.courses}</Link></li>
              <li><Link to="/blog" className="text-gray-400 hover:text-white transition-colors">{t.links.blog}</Link></li>
              <li><Link to="/contact" className="text-gray-400 hover:text-white transition-colors">{t.links.contact}</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4">{t.services}</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">{t.servicesList.healing}</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">{t.servicesList.consultation}</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">{t.servicesList.workshops}</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">{t.servicesList.courses}</a></li>
            </ul>
          </div>

          {/* Contact & Newsletter */}
          <div>
            <h3 className="text-lg font-semibold mb-4">{t.contact}</h3>
            <div className="space-y-3 mb-6">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <Phone className="h-5 w-5 text-gray-400" />
                <span className="text-gray-400">+20 123 456 7890</span>
              </div>
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <Mail className="h-5 w-5 text-gray-400" />
                <span className="text-gray-400">info@omarali.com</span>
              </div>
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <MapPin className="h-5 w-5 text-gray-400" />
                <span className="text-gray-400">Cairo, Egypt</span>
              </div>
            </div>

            <h4 className="text-md font-semibold mb-2">{t.newsletter}</h4>
            <p className="text-gray-400 text-sm mb-4">{t.newsletterText}</p>
            <div className="flex">
              <input
                type="email"
                placeholder={t.emailPlaceholder}
                className="flex-1 px-3 py-2 bg-gray-800 border border-gray-700 rounded-l-md text-white placeholder-gray-400 focus:outline-none focus:border-primary"
              />
              <button className="px-4 py-2 bg-primary text-white rounded-r-md hover:bg-primary/90 transition-colors">
                {t.subscribe}
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2024 {t.name}. {t.rights}
          </p>
          <div className="flex space-x-6 rtl:space-x-reverse mt-4 md:mt-0">
            <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">{t.privacy}</a>
            <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">{t.terms}</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

